# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.4 (16/07/22)
# // Developer: Florian Valente
# // 
# // Purpose:   Set WinRM
# // Usage:     SetWinRM.ps1 -<args>
# //            Args:
# //            [-Transport]: HTTP, HTTPS
# //            [-AutoEnrollGroup]: Check if AD computer membership is defined for autoenrollment
# //            [-WinRMGroup]: Set the local WinRM group (in case of HTTPS)
# //            [-MaxMemoryPerShellMB]: Set the maximum amount of memory allocated per shell
# //            [-SkipADCheck]: Use this switch to skip the AD computer membership check
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("HTTP", "HTTPS")] $Transport = "HTTP",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $AutoEnrollGroup = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $WinRMGroup = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Int] $MaxMemoryPerShellMB = 1024,
	[Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $SkipADCheck
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Get-ADMembership {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Name
    )

    # Boolean returned by the function that indicates that AD membership was found
    $bFound = $false

    try {
        If ((!([system.string]::IsNullOrEmpty($env:LOGONSERVER))) -and (($env:LOGONSERVER).Substring(2) -notmatch $env:COMPUTERNAME)) {
            $strFilter = "(&(objectCategory=Computer)(samAccountName=$($env:COMPUTERNAME)$))"

            $objSearcher = New-Object System.DirectoryServices.DirectorySearcher
            $objSearcher.Filter = $strFilter

            $objPath = $objSearcher.FindOne()
            $objComputer = $objPath.GetDirectoryEntry()
        }
        Else {
            # Cannot use New-Object System.DirectoryServices.DirectorySearcher because script is launched as local admin
            # So must use Name Translate
            $ADS_NAME_INITTYPE_DOMAIN = 1
            $ADS_NAME_TYPE_NT4 = 3
            $ADS_SERVER_BIND = 512
            $ADS_SECURE_AUTHENTICATION = 1
			
			# Obtain FQDN of closest domain controller
            # [ADSI]"LDAP://$JoinDomain/RootDSE" not works under Local Admin Session
            $strFQDN = (nltest /dsgetdc:$($tsenv:JoinDomain))[0].SubString(17)
            Write-Host "Closest DC found: $strFQDN"

	        # Open user object via LDAP
	        $Trans = New-Object -ComObject NameTranslate
            $objNT = $Trans.GetType()

            # Specify credentials for NameTranslate to authenticate the domain
            Write-Host "Trying to connect to AD with $tsenv:OSDJoinAccount account..."
            If ([String]::IsNullOrEmpty($tsenv:OSDJoinAccount)) {
                Write-Warning "Cannot connect to AD to check if server is member of $Name Group"
                return $bFound
            }

            $strDomainName = Split-Path $tsenv:OSDJoinAccount -Parent #Get domain
            $strAccountName = Split-Path $tsenv:OSDJoinAccount -Leaf #Get account
            # DomainAdminDomain, DomainAdmin and DomainAdminPassword variables cannot be used since MDT 2012
            $objNT.InvokeMember("InitEx", "InvokeMethod", $null, $Trans, ($ADS_NAME_TYPE_NT4, "$strDomainName", "$strAccountName", "$strDomainName", "$tsenv:OSDJoinPassword"))
            Write-Host "Connection made"

	        # Find server in the Domain
	        $strComputerName = "$strDomainName\$env:COMPUTERNAME$"
            $objNT.InvokeMember("Set", "InvokeMethod", $null, $Trans, ($ADS_NAME_TYPE_NT4, "$strComputerName"))

            $strComputerDN = $objNT.InvokeMember("Get", "InvokeMethod", $null, $Trans, ($ADS_NAME_INITTYPE_DOMAIN))
            Write-Host "DN found: $strComputerDN"

	        # Bind computer object via LDAP using FQDN of nearest domain controller and supplied credentials
	        $objComputer = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$strFQDN/$strComputerDN", $strAccountName, $tsenv:OSDJoinPassword, $($ADS_SECURE_AUTHENTICATION + $ADS_SERVER_BIND))
        }

        # Check if server is member of the specified group
        ForEach ($member in $objComputer.memberOf) {
            If ($member -match $Name) {
                $bFound = $true
                break
            }
        }
    }
    catch {
        Write-Warning "Computer account $($env:COMPUTERNAME) not found in AD! $($_.Exception.Message)"
        return $bFound
	}
    
    If (!($bFound)) {
        Write-Warning "Server is not member of AD Group $Name. Please check it"
    }

    return $bFound
}


Function Add-LocalGroup {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Name
    )

    try {
        $computer = [ADSI]"WinNT://$env:COMPUTERNAME,computer"
        
        # Test if the group already exists
        $colGroups = ($Computer.psbase.children | Where-Object {$_.psBase.schemaClassName -eq "Group"} | Select-Object -ExpandProperty Name)
        If (!($colGroups -contains $Name)) {
            # Create the local group
            $localGroup = $computer.Create("group",$Name)
            $localGroup.SetInfo()

            # Set the description
            $localGroup.description = "Group granted to WinRM SDDL (Full Rights)"
            $localGroup.SetInfo()

            Write-Host "Local Group $Name created successfully"
        }
        Else {
            Write-Host "Local Group $Name already exists"
        }
    }
    catch {
        Write-Error "ERROR: During the creation of the local group! $($_.Exception.Message)"
    }
}


Function Get-LocalGroupSID {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Name
    )

    try {
        # Get local group SID
        $objUser = New-Object System.Security.Principal.NTAccount($Name)
        $strSID = ($objUser.Translate([System.Security.Principal.SecurityIdentifier])).Value

        Write-Host "$Name SID: $strSID"
        return $strSID
    }
    catch {
        Write-Error "Cannot get SID of $Name!"
    }
}


########
# MAIN #
########
try {	
    # Configure WinRM with HTTPS only if the server is in a domain
    If (Test-JoinDomain) {
		# Restart winrm service before configuring it (in order to avoid certificate issue for https listening)
		Restart-Service winrm
		
        # Configure WinRM by default
        Invoke-Expression -Command "cmd /c winrm quickconfig -q"
        Write-Host "WinRM enabled"

        # Configure Max memory per shell to 1024MB
        Invoke-Expression -Command ("cmd /c winrm set winrm/config/winrs '@{MaxMemoryPerShellMB=""" + $MaxMemoryPerShellMB + """}'")
        Write-Host "WinRM MaxMemoryPerShell set to $MaxMemoryPerShellMB"

        If ($Transport -eq "HTTPS") {
            # Configure certificate authentication
            Invoke-Expression -Command "cmd /c winrm set winrm/config/service/auth '@{Certificate=""true""}'"
            Write-Host "WinRM with Certificate enabled"

			If($SkipADCheck) {
				# To avoid AD check during Post-installation package
				$bFound = $true
			}
			ElseIf ($AutoEnrollGroup -eq "") {
                Write-Host "No AutoEnroll Group was defined"
                $bFound = $true
            }
            Else {
				$bFound = Get-ADMembership -Name $AutoEnrollGroup
			}
			
			If ($bFound) {
                Write-Host "Server is member of $AutoEnrollGroup AD group"
                try {
                    # Get all local certificates with computer name/fqdn and grant network service permissions on it
                    $certs = dir cert:\LocalMachine\my
                    ForEach ($cert in $certs) {
                        If (($cert.Subject -eq ('CN=' + $env:COMPUTERNAME)) -or ($cert.Subject -eq ('CN=' + [System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName))) {
                            Write-Host ("Fixing permissions on " + $cert.Thumbprint + " " + $cert.Subject + "...")
                            $location = $cert.PrivateKey.CspKeyContainerInfo.UniqueKeyContainerName
                            $folderlocation = gc env:ALLUSERSPROFILE
                            $folderlocation = $folderlocation + "\Microsoft\Crypto\RSA\MachineKeys\"
                            $filelocation = $folderlocation + $location
                            #icacls $filelocation /grant "Network service:(OI)(CI)(F)"
                            icacls $filelocation /grant "Network service:(F)"
                            Write-Host "Permissions set"
                        }
                    }
                }
                catch {
                    Write-Warning "An error occurred during fix cert permissions. $($_.Exception.Message)"
                }


                If ($WinRMGroup -ne "") {
                    # Create local group $WinRMGroup and grant it for WinRM Full Rights
                    Add-LocalGroup -Name $WinRMGroup

                    # Get SID of the local group
                    $SID = Get-LocalGroupSID -Name $WinRMGroup

                    # grant the local group to WinRM SDDL (Full rights) 
                    Invoke-Expression -Command ("cmd /c winrm set winrm/config/Service '@{RootSDDL=""O:NSG:BAD:P(A;;GA;;;BA)(A;;GA;;;" + $SID + ")S:P(AU;FA;GA;;;WD)(AU;SA;GXGW;;;WD)""}'")
                    Write-Host "$WinRMGroup granted to WinRM SDDL with Full Rights"
                }

                # Enable the auto-enrollment local policy, allow renew certificates, update pending certificates, and remove revoked certificates configured
				If(!(Test-Path "HKLM:\Software\Policies\Microsoft\Cryptography\AutoEnrollment")) {
					New-Item -Path "HKLM:\Software\Policies\Microsoft\Cryptography" -Name "AutoEnrollment"
				}
                New-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Cryptography\AutoEnrollment\" -Name "AEPolicy" -Value "6" -Type "DWord" -Force | Out-Null
                Write-Host "HKLM\Software\Policies\Microsoft\Cryptography\AutoEnrollment\AEPolicy set to 6"

                # Waiting for 10 seconds
                Start-Sleep 10

                try {
                    # Configure a HTTPS listener to WinRM using the first personnal certificate matching with WinRM specs
                    Invoke-Expression -Command "cmd /c winrm quickconfig -transport:https -q"
                    Write-Host "HTTPS listener configured successfully"
                }
                catch {
                    Write-Warning "Cannot set WinRM in HTTPS. $($_.Exception.Message)"
                    exit
                }

                Write-Host "WinRM Transport configured to HTTPS"
            }
            Else {
                Write-Host "Cannot set WinRM in HTTPS"
            }
        }
        Else {
            Write-Host "WinRM Transport configured to HTTP"
        }
    }
    Else {
        Write-Host "Server not in a Domain. Nothing to do"
    }
}
catch {
    Write-Error "ERROR: WinRM Configuration failed $($_.Exception.Message)"
}

