<#
.SYNOPSIS
	Configure Hardening on Postinstall to correct issue when using Standalone Media

.DESCRIPTION
	Configure Hardening on Postinstall to correct issue when using Standalone Media

.LINK
	

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.1 (2016/06/01)
    ChangeLog: 

.EXAMPLE
	./SetHardening.ps1

	./Script_template.ps1 -Level ADVANCED

#>

# Optional - Only if there are parameters
[CmdletBinding()]
PARAM (
	[Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("FOUNDATION", "ADVANCED","PREMIUM","PREMIUMPLUS")][String] $Level = ""
)

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################
# Default available variables:
# - $PSScriptRoot: Script path
# - $PSScriptName: Script name without extension
# - $tsenv:SGDept: Department
# Get Conf folder
$PSConfPath = "$PSScriptRoot\conf"

# Using MDT Variables
#$tsenv:SGOSCode
#$tsenv:SGGPOPackName



##################################################
##                     MAIN                     ##
##################################################
# Get OS family code (ex for NT112, family code is NT110)
$sFamilyCode = $tsenv:SGOSCode.Substring(0, $tsenv:SGOSCode.Length-1) + "0"

# Get GPO Pack name
$sGPOPackPath = "SG-$sFamilyCode-"

If ($Level -ne "") {
    Write-Host "Hardening Level get from parameter: $Level"
    $sGPOPackPath += $Level.ToUpper()
    Set-ItemProperty "$tsenv:SGRegTagPath\parameters" -Name "HARDENING" -Value "$Level"
}
ElseIf (!([System.String]::IsNullOrEmpty($tsenv:SGGPOPackName))) {
    $sGPOPackPath += $tsenv:SGGPOPackName
}
ElseIf (!([System.String]::IsNullOrEmpty((Get-ItemProperty "$tsenv:SGRegTagPath\parameters")."HARDENING"))) {
    $sGPOPackPath += (Get-ItemProperty "$tsenv:SGRegTagPath\parameters")."HARDENING"
}
Write-Host "Using GPO Pack $sGPOPackPath"

# Check if path is valid
$sGPOPackFullPath = "$tsenv:DeployRoot\Templates\GPOPacks\$sGPOPackPath"
If (!(Test-Path $sGPOPackFullPath)) {
	Write-Error "GPO Pack folder not found"
}

try {
    # Set GPO Pack local path
    $sGPOPackLocalPath = "$env:APPDATA\$sGPOPackPath"
    New-Item $sGPOPackLocalPath -ItemType directory -Force

    # Copy GPO Pack to local path
    Copy-Item "$sGPOPackFullPath\*" -Destination $sGPOPackLocalPath -Recurse -Force | Out-Null

    # Run GPO Pack script
    Write-Host "Running GPO Pack..."
    $oStatus = Start-Process -FilePath "cmd.exe" -ArgumentList "/c cscript.exe ""$sGPOPackLocalPath\GPOPack.wsf"" /Path:""$sGPOPackLocalPath"" /silent" -PassThru -Wait
    If ($oStatus.ExitCode -eq 0) {
        Write-Host "GPO Pack applied successfully"
    }
    Else {
        Write-Error "GPO Pack not applied!"
    }

    # Remove GPO Pack local folder
    Remove-Item $sGPOPackLocalPath -Recurse -Force | Out-Null
}
catch {
    Write-Error "Cannot apply GPO Pack $sGPOPackPath! $($_.Exception.Message)"
}

