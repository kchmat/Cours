# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   5.0 (16/02/01)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Network Teaming
# // Usage:     SetNetworkTeaming.ps1 -<args>
# //            Args:
# //            -TeamName: Name of the Network Team
# //            [-TeamMembersName]: Name of the Network Adapter members of the Team
# //            [-TeamingMode]: Teaming Mode of the Team. Must be equals to Lacp, Static or SwitchIndependent (Default: SwitchIndependent)
# //            [-LBMode]: Load Balancing Mode of the Team. Must be equals to Dynamic, HyperVPort, IPAddresses, MacAddresses,TransportPorts (Default: Dynamic)
# //            [-StandbyAdapter]: Standby network adapter number (only when SwitchIndependent is choosen)
# //            [-NbAdapters]: Number of network adapters to add to the team (Default: 2)
# //            [-ConfFile]: Vendor configuration file path used to configure teaming
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Make,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $TeamName,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $TeamMembersName = "LAN",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Lacp","Static","SwitchIndependent")][String] $TeamingMode = "SwitchIndependent",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Dynamic","HyperVPort","IPAddresses","MacAddresses","TransportPorts")][String] $LBMode = "Dynamic",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Int] $StandbyAdapter = 0,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Int] $NbAdapters = 2,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $ConfFile = "fakename"
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


########
# MAIN #
########
# If VM, no teaming
If ($tsenv:IsVM -eq "True") {
    Write-Host "VM detected. Nothing to do."
    exit
}

# Be sure that there is only one network adapter with a gateway set
$oNetAdapter = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled='True'" | Where-Object {$_.DefaultIPGateway -ne $null}
If ($oNetAdapter.Count -ne $null) {
    # More than one adapter has got a gateway. Otherwise Count parameter does not exists
    Write-Warning "More than one Network Adapter is configured with a gateway. Teaming cannot be configured!"
    Exit
}

# Set the active adapter
# Used in brand teaming scripts
$oActiveNetAdapter = $oNetAdapter | Select-Object -First 1

# Load Generic Functions
try {
    . "$PSScriptRoot\bin\Generic-Functions.ps1"
}
catch {
    Write-Error "Generic binary files not found! Please contact an administrator"
}


# Set full path of the conf file
$ConfFile = "$PSScriptRoot\$ConfFile"

# Set a boolean in case of teaming configuration done successfully
$bConfigDone = $false

# Set default parameters to bind to Teaming functions
$paramTeam = @{
    TeamName = $TeamName
    TeamMembersName = $TeamMembersName
    PrimaryAdapter = $oActiveNetAdapter
}


# Set Teaming corresponding to the server's vendor
If ($Make -eq "Microsoft" -and (Get-OSVersion) -ge 6.3) {
    Write-Host "At least Windows Server 2012 R2 was found. Using Microsoft Teaming Tool..."
    # Load Microsoft Teaming Functions
    try {
        . "$PSScriptRoot\bin\$Make\$Make-Functions.ps1"
    }
    catch {
        Write-Error "$Make Teaming binary files not found! Please contact an administrator"
    }

    $paramTeam += @{
        TeamingMode = $TeamingMode
        LBMode = $LBMode
        StandbyAdapter = $StandbyAdapter
        NbAdapters = $NbAdapters
    }
    Set-MSTeaming @paramTeam
    $bConfigDone = $true
}

If ((Get-OSVersion) -lt 6.3) {
    Switch ($Make) {
        "Microsoft" {
            Write-Host "$Make Teaming doesn't exists under Windows Server 2008 R2. Nothing to do"
            Exit
        }

        "HP" {
            If ($tsenv:Make -ne "HP") {
                Write-Host "Not an $Make Server. Exit"
                Exit
            }

            Write-Host "$Make server was detected"

            # Load HP Teaming Functions
            try {
                . "$PSScriptRoot\bin\$Make\$Make-Functions.ps1"
            }
            catch {
                Write-Error "$Make Teaming binary files not found! Please contact an administrator"
            }

            $oNet = Get-NetAdapterManufacturerInfo -Adapter $oActiveNetAdapter
            # Get the server generation
            [Int]$iServerGen = $tsenv:Model -split "(Gen|(?:g|G))" | Select-Object -Last 1

            # NCU is not supported on Gen9 for some net adapter manufacturers
            $bNCU = $true
            If ($iServerGen -ge 9) {
                try {
                    Start-Process "cqniccmd.exe" -Wait -ErrorAction SilentlyContinue
                }
                catch {
                    $bNCU = $false
                }

                If (!($bNCU)) {
                    Write-Host "NCU Tool is not supported for this configuration!"
                    Write-Host "Using $($oNet.Name) Tool to create the Network Team..."
                    Set-BrandTeaming -Name $oNet.Name
                    $bConfigDone = $true
                }
            }
            
            If ($bNCU) {
                Write-Host "Using NCU Tool..."
                $paramTeam += @{
                    ConfFile = $ConfFile
                }
                Set-HPTeaming @paramTeam
                # Magic rubber trick in case of HP teaming...
                $oNet.Service = "CPQTeamMP"
                $bConfigDone = $true
            }
        }

        "Dell" {
            If ($tsenv:Make -ne "Dell Inc.") {
                Write-Host "Not a $Make Server. Exit"
                Exit
            }

            Write-Host "$Make server was detected"

            $oNet = Get-NetAdapterManufacturerInfo -Adapter $oActiveNetAdapter
            Write-Host "Using $($oNet.Name) Tool to create the Network Team..."
            Set-BrandTeaming -Name $oNet.Name
            $bConfigDone = $true
        }

        <#
        "<MANUFACTURER>" {
            If ($tsenv:Make -ne "<MANUFACTURER>") {
                Write-Host "Not a <MANUFACTURER> Server. Exit"
                Exit
            }

            Write-Host "$Make parameter found"

            # Load <MANUFACTURER> Teaming Functions
            try {
                . "$PSScriptRoot\bin\$Make\$Make-Functions.ps1"
            }
            catch {
                Write-Error "$Make Teaming binary files not found! Please contact an administrator"
            }

            $paramTeam += @{
                #Add used parameters
                #TeamingMode = $TeamingMode
                #LBMode = $LBMode
                #StandbyAdapter = $StandbyAdapter
                #NbAdapters = $NbAdapters
            }

            Set-<MANUFACTURER>Teaming @paramTeam
            $bConfigDone = $true
        }
        #>

        Default {
            Write-Warning "$Make not managed in the script. Please contact an administrator"
            Exit
        }
    }

    # Set network adapter because teaming configuration lost initial network settings
    Set-NetworkAdapter -Adapter $oActiveNetAdapter -Name $TeamName -ServiceName $oNet.Service
}

If ($bConfigDone) {
    # Force NIC settings capture in case of deployment (not necessary on postinstall under Software Catalog for example)
    # To avoid error during Apply Network Settings Deployment Task which occurs after each computer restart
    $ScriptPath = [System.IO.Path]::GetPathRoot($tsenv:LogPath) + "MININT\Scripts\ZTINICConfig.wsf"
    If (Test-Path $ScriptPath) {
        Write-Host "Forcing Capture of NIC Config by using MDT ZTINICConfig.wsf script..."
        Start-Process "cscript.exe" -ArgumentList """$ScriptPath"" /ForceCapture" -Wait
    }
}
