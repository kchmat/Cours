# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   2.2 (15/04/01)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Network Teaming
# // Usage:     SetNetworkTeaming.ps1 -<args>
# //            Args:
# //            -TeamName: Name of the Network Team
# //            [-TeamMembersName]: Name of the Network Adapter members of the Team
# //            [-TeamingMode]: Teaming Mode of the Team. Must be equals to Lacp, Static or SwitchIndependent (Default: SwitchIndependent)
# //            [-LBMode]: Load Balancing Mode of the Team. Must be equals to Dynamic, HyperVPort, IPAddresses, MacAddresses,TransportPorts (Default: Dynamic)
# //            [-NbAdapters]: Number of network adapters to add to the team (Default: 2)
# //            [-ConfFile]: Vendor configuration file path used to configure teaming
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Make,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $TeamName,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $TeamMembersName = "LAN",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Lacp","Static","SwitchIndependent")] $TeamingMode = "SwitchIndependent",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Dynamic","HyperVPort","IPAddresses","MacAddresses","TransportPorts")] $LBMode = "Dynamic",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Int] $NbAdapters = 2,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $ConfFile = "fakename"
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


# // Purpose:   Set Microsoft Network Teaming
# // Usage:     Set-MSTeaming
# //            Args:
# //            -TeamName: Name of the Network Team
# //            [-TeamMembersName]: Name of the Network Adapter members of the Team
# //            [-TeamingMode]: Teaming Mode of the Team. Must be equals to Lacp, Static or SwitchIndependent (Default: SwitchIndependent)
# //            [-LBMode]: Load Balancing Mode of the Team. Must be equals to Dynamic, HyperVPort, IPAddresses, MacAddresses,TransportPorts (Default: Dynamic)
# //            [-NbAdapters]: Number of network adapters to add to the team (Default: 2)
Function Set-MSTeaming {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $TeamName,
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $TeamMembersName = "LAN",
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Lacp","Static","SwitchIndependent")] $TeamingMode = "SwitchIndependent",
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Dynamic","HyperVPort","IPAddresses","MacAddresses","TransportPorts")] $LBMode = "Dynamic",
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Int] $NbAdapters = 2
    )

    # Launch command
    try {
        # Removing all Teams already created
        Write-Host "Removing Teaming already created..."
        Get-NetLbfoTeam | Remove-NetLbfoTeam -Confirm:$false
        Start-Sleep 10
        Write-Host "Teams removed successfully"

        # Get all network information of the network adapter before creating the teaming
        $oNetInfo = Get-NetIPConfiguration | Where-Object {$_.IPv4Address.IPAddress -eq $oNetAdapter.IPAddress[0]}

        # Get all network adapters with network cable plugged
        # Number of adapters found here ($NbAdapters max) will be use for the teaming
        $oNetUp = Get-NetAdapter | Where-Object {$_.Status -eq "Up"} | Select-Object -First $NbAdapters
        If ($oNetUp.Count -eq $null) {
            If ($tsenv:IsVM -eq "False") {
                Write-Warning "Only one Network Adapter is Up. Teaming cannot be configured!"
            }
            Else {
                Write-Host "Only one Network Adapter is Up but it's a VM, so OK."
            }
            Exit
        }
        Else {
            Write-Host "Number of Network Adapters found: $($oNetUp.Count)"
        }

        # Creation of the teaming
        Write-Host "Creating Teaming..."
        $Args = @{
            TeamMembers = $oNetUp.Name
            Name = $TeamName
            TeamingMode = $TeamingMode
            LoadBalancingAlgorithm = $LBMode
        }
        New-NetLbfoTeam @Args -Confirm:$false
        Write-Host "Teaming created"
        Start-Sleep 10
    }
    catch {
        Write-Error "[Set-MSTeaming] Teaming not created. $($_.Exception.message)"
    }

    try {
        # Set IP Information to the Team (gets previously on Active Network Adapter)
        $Args = @{
            InterfaceAlias = $TeamName
            AddressFamily = "IPv4"
            IPAddress = $oNetInfo.IPv4Address.IPAddress
            DefaultGateway = $oNetInfo.IPv4DefaultGateway.NextHop
            PrefixLength = $oNetInfo.IPv4Address.PrefixLength
        }
        New-NetIPAddress @Args -Confirm:$false
        Write-Host "Network information applied successfully to $TeamName"

        # Set DNS Servers IP to the Team
        $Args = @{
            InterfaceAlias = $TeamName
            ServerAddresses = $oNetInfo.DNSServer.ServerAddresses
        }
        Set-DnsClientServerAddress @Args -Confirm:$false
        Write-Host "DNS information applied successfully to $TeamName"

        # Rename Network Adapter members
        Write-Host "Renaming Network Adapters to $($TeamMembersName)x"
        #Get Network Adapter members of the Team sorted by Interface Description (to avoid issue during a deployment and renaming of the first netcard)
        $oTeamMembers = (Get-NetLbfoTeam -Name $TeamName).Members | % {Get-NetAdapter -Name $_} | Sort-Object InterfaceDescription
        $cpt = 1
        $oTeamMembers | % {
            Rename-NetAdapter -Name $_.Name -NewName "$($TeamMembersName)$cpt"
            $cpt++
        }

        Start-Sleep 10 #Wait to avoid issue in the Task Sequence after resetting network configuration

        Write-Host "Teaming configured successfully!"

        # Edit MDT Network Adapter Name to avoid issue during the deployment
        $tsenv:OSDAdapter0Name = "$TeamName"
    }
    catch {
        Write-Warning "[Set-MSTeaming] Teaming not configured. $($_.Exception.message)"
    }
}


# // Purpose:   Set HP Network Teaming by using 
# // Usage:     Set-HPTeaming
# //            Args:
# //            -TeamName: Name of the Network Team
# //            [-TeamMembersName]: Name of the Network Adapter members of the Team
# //            -ConfFile: HP XML Configuration file
Function Set-HPTeaming {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $TeamName,
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $TeamMembersName,
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile
    )

    If ($tsenv:Make -ne "HP") {
        Write-Host "$tsenv:Make is not HP! Exit"
        Exit
    }

    try {
        # Get the Generation of the HP server (ex Gen8 on ProLiant DL360 Gen8)
        $HPGen = $tsenv:Model -split " " | Select-Object -Last 1
        $ConfFileName = [System.IO.Path]::GetFileNameWithoutExtension($ConfFile)
        # Check if a file containing the server Generation in its name exists
        $HPTmpConfFileName = $ConfFile -replace $ConfFileName, "$ConfFileName-$HPGen"
        If (Test-Path $HPTmpConfFileName) {
            $ConfFile = $HPTmpConfFileName
        }
        Else {
            If (!(Test-Path $ConfFile)) {
                Write-Warning "$ConfFile not found. Cannot configure $Make Teaming!"
                Exit
            }
        }
        Write-Host "Configuration File found: $ConfFile"
    
        # Set Local Path of the conf file
        $LocalConfFilePath = "$LocalPath\$(Split-Path $ConfFile -Leaf)"
        # Copy conf file locally to avoid issue in case of network connectivity loss
        Copy-Item $ConfFile -Destination $LocalConfFilePath -Force | Out-Null
        # Reset Read Only attribute to avoid issue when using a Standalone Media
        (Get-Item $LocalConfFilePath).IsReadOnly = $false
        Write-Host "Conf File copied to $LocalConfFilePath"

        # Update the XML file with the TeamName and set the active MAC Address for Team adapter
        $xml = [xml](Get-Content $LocalConfFilePath)
        $xml.teamingconfig.team.property | % {
            If ($_.id -eq "TeamName") { $_.value = $TeamName }
            If ($_.id -eq "TeamNetworkAddress") { $_.value = ($tsenv:MACAddress001 -replace ":", "-") }
        }
        $xml.Save($LocalConfFilePath)
        Write-Host "Configuration File updated"
        
        # Parse the conf file to check for syntax errors
        Write-Host "Parsing the conf file to check for syntax errors..."
        $objResult = Start-Process "cqniccmd.exe" -ArgumentList "/P ""$LocalConfFilePath""" -PassThru -Wait
        If ($objResult.ExitCode -eq 0) {
            Write-Host "Configuration File checked successfully"
        }
        Else {
            Write-Error "Syntax errors found on the configuration File! Exit"
        }

        # Remove all previous HP teaming created
        Write-Host "Removing Teaming already created..."
        $objResult = Start-Process "cqniccmd.exe" -ArgumentList "/D" -PassThru -Wait
        If ($objResult.ExitCode -eq 0) {
            Write-Host "All Teaming removed successfully"
        }
        Else {
            Write-Error "Teaming not removed successfully! Exit"
        }

        # Set the teaming
        Write-Host "Configuring the Teaming..."
        $objResult = Start-Process "cqniccmd.exe" -ArgumentList "/C ""$LocalConfFilePath""" -PassThru -Wait
        If ($objResult.ExitCode -eq 0) {
            Write-Host "Teaming configured successfully"
        }
        Else {
            Write-Error "Teaming not configured! Exit"
        }

        Start-Sleep 10 #Wait to avoid issue in the Task Sequence after resetting network configuration

        # Edit MDT Network Adapter Name to avoid issue during the deployment
        $tsenv:OSDAdapter0Name = "$TeamName"
    }
    catch {
        Write-Error "[Set-HPTeaming] Teaming not configured. $($_.Exception.Message)"
    }
}


Function Set-NetworkAdapter {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Name,
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ServiceName
    )

    try {
        $netInfo = Get-WmiObject Win32_NetworkAdapter -Filter "MACAddress='$tsenv:MACAddress001' AND ServiceName='$ServiceName'"
        $netConf = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "MACAddress='$tsenv:MACAddress001' AND ServiceName='$ServiceName'"
        
        # Release any acquired DHCP address
	    If ($netConf.DHCPEnabled) {
		    If ($netConf.DHCPServer -ne $null) {
			    If ($netConf.DHCPServer -ne "255.255.255.255") {
				    $netConf.ReleaseDHCPLeaseAll()
                    Write-Host "DHCP Leases released"
			    }
		    }
	    }

        # Remove IPv6 of IP Addresses and Subnets list
        $IPAddresses = $oNetAdapter.IPAddress | Where-Object { $_ -notmatch ":" }
        $IPSubnet = $oNetAdapter.IPSubnet | Where-Object { $_ -match "[.]" }

        Write-Host "Configuring Network of Teaming Adapter..."
        $netConf.EnableStatic($IPAddresses, $IPSubnet)
        $netConf.SetGateways($oNetAdapter.DefaultIPGateway, $oNetAdapter.GatewayCostMetric)
        $netConf.SetDNSServerSearchOrder($oNetAdapter.DNSServerSearchOrder)
        $netConf.SetWINSServer($oNetAdapter.WINSPrimaryServer, $oNetAdapter.WINSSecondaryServer)
        $netConf.SetDynamicDNSRegistration($oNetAdapter.FullDNSRegistrationEnabled, $oNetAdapter.DomainDNSRegistrationEnabled)
        $netConf.SetIPConnectionMetric($oNetAdapter.IPConnectionMetric)
        $netConf.SetTcpipNetbios($oNetAdapter.TcpipNetbiosOptions)
        Write-Host "Network Adapter configured successfully"

        Write-Host "Renaming the Teaming Adapter to $Name"
        $netInfo.NetConnectionID = $Name
        $netInfo.Put()

        Start-Sleep 30 #Long wait to avoid issue in the Task Sequence after resetting network configuration
    }
    catch {
        Write-Error "[Set-NetworkAdapter] Cannot set the Network Adapter. $($_.Exception.Message)"
    }
}


########
# MAIN #
########
# If VM, no teaming
If ($tsenv:IsVM -eq "True") {
    Write-Host "VM detected. Nothing to do."
    exit
}

# Be sure that there is only one network adapter with a gateway setted
$oNetAdapter = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled='True'" | Where-Object {$_.DefaultIPGateway -ne $null}
If ($oNetAdapter.Count -ne $null) {
    # More than one adapter has got a gateway. Otherwise Count parameter does not exists
    Write-Warning "More than one Network Adapter is configured with a gateway. Teaming cannot be configured!"
    Exit
}

# Set full path of the conf file
$ConfFile = "$PSScriptRoot\$ConfFile"

# Set the local path for files copy
$LocalPath = "$env:SystemRoot\Temp\Teaming"
If (!(Test-Path $LocalPath)) { New-Item $LocalPath -ItemType directory -Force | Out-Null }

# Set a boolean in case of teaming configuration done
$bConfigDone = $false

# Set Teaming corresponding to the server's vendor

If ($Make -eq "Microsoft" -and (Get-OSVersion) -ge 6.3) {
    Write-Host "$Make parameter found"
    Set-MSTeaming -TeamName $TeamName -TeamMembersName $TeamMembersName
    $bConfigDone = $true
}

If ((Get-OSVersion) -lt 6.3) {
    Switch ($Make) {
        "Microsoft" {
            Write-Host "Microsoft Teaming doesn't exists under Windows Server 2008 R2. Nothing to do"
        }

        "HP" {
            Write-Host "$Make parameter found"
    
            Set-HPTeaming -TeamName $TeamName -TeamMembersName $TeamMembersName -ConfFile $ConfFile

            # Set network adapter because teaming configuration lost initial network settings
            Set-NetworkAdapter -Name $TeamName -ServiceName "CPQTeamMP"

            $bConfigDone = $true
        }

        <#
        "Dell" {
            Set-DellTeaming -TeamName $TeamName -TeamMembersName $TeamMembersName -ConfFile $LocalConfFilePath

            Set-NetworkAdapter -Name $TeamName -ServiceName ""

            $bConfigDone = $true
        }

        "IBM" {
            Set-IBMTeaming -TeamName $TeamName -TeamMembersName $TeamMembersName -ConfFile $LocalConfFilePath

            Set-NetworkAdapter -Name $TeamName -ServiceName ""

            $bConfigDone = $true
        }

        "Ciara" {
            Set-CiaraTeaming -TeamName $TeamName -TeamMembersName $TeamMembersName -ConfFile $LocalConfFilePath

            Set-NetworkAdapter -Name $TeamName -ServiceName ""

            $bConfigDone = $true
        }
        #>

        Default {
            Write-Warning "$Make not managed in the script. Please contact a G-WiM Administrator"
        }
    }
}

If ($bConfigDone) {
    # Force NIC settings capture in case of deployment (not necessary on postinstall under Software Catalog for example)
    # To avoid error during Apply Network Settings Deployment Task which occurs after each computer restart
    $ScriptPath = [System.IO.Path]::GetPathRoot($tsenv:LogPath) + "MININT\Scripts\ZTINICConfig.wsf"
    If (Test-Path $ScriptPath) {
        Write-Host "Forcing Capture of NIC Config by using MDT ZTINICConfig.wsf script..."
        Start-Process "cscript.exe" -ArgumentList """$ScriptPath"" /ForceCapture" -Wait
    }
}

# Cleaning Local folder
Write-Host "Cleaning folder $LocalPath..."
Remove-Item $LocalPath -Recurse -Force | Out-Null