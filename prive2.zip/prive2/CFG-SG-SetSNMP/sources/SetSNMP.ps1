# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (16/01/21)
# // Developer: Florian Valente
# // 
# // Purpose:   Set SNMP
# // Usage:     SetSNMP.ps1 -File <confFile.xml>
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $File
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Get-SNMPConfig {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Hardware
    )

    # Parse XML
    $xml = [xml](Get-Content $xmlFile)

    # Set Node by Hardware
    $xmlNode = $xml.SelectSingleNode("//configuration/hardware[@name='$Hardware']")
    If ($xmlNode -eq $null) {
        Write-Host "Hardware Node $Hardware doesn't exist on XML file! Exit"
    }
    Else {
        Write-Host "Node $Hardware found!"
    }

    return $xmlNode
}


Function Set-SNMPParameters {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$false)][String] $Contact = "",
        [Parameter(Mandatory=$false)][String] $Location = "",
        [Parameter(Mandatory=$false)][Int] $EnableAuthTraps = 0,
        [Parameter(Mandatory=$false)][Int] $NameResRetries = 16,
        [Parameter(Mandatory=$false)] $Services = "",
        [Parameter(Mandatory=$false)] $Managers = "*"
    )

try {
        # Set Enable Authentication Traps
        New-ItemProperty -Path $strSNMPRegPath -Name "EnableAuthenticationTraps" -Value $EnableAuthTraps -Force | Out-Null
        # Set Name Resolution Entries
        New-ItemProperty -Path $strSNMPRegPath -Name "NameResolutionRetries" -Value $NameResRetries -Force | Out-Null

        # Set reg path for set up parameters
        $strRegPath = "$strSNMPRegPath\RFC1156Agent"

        # Set sysContact
        If ($Contact -ne "") {
            New-ItemProperty -Path $strRegPath -Name "sysContact" -Value "$Contact" -Force | Out-Null
            Write-Host "Contact setted: $Contact"
        }

        # Set sysLocation
        If ($Location -ne "") {
            New-ItemProperty -Path $strRegPath -Name "sysLocation" -Value "$Location" -Force | Out-Null
            Write-Host "Location setted: $Location"
        }

        # Set Services
        If ($Services -ne "") {
            $intService = 0
            ForEach ($svc in $Services) {
                Switch ($svc) {
                    "Physical" {$intService += 1}
                    "Applications" {$intService += 64}
                    "Datalink" {$intService += 2}
                    "Internet" {$intService += 4}
                    "Endtoend" {$intService += 8}
                    default {$intService += 0}
                }
            }
        }
        Else {
            $intService = 76
            Write-Host "No Services defined. Applications, Internet and Endtoend are setted by default."
            $Services = "Applications Internet Endtoend"
        }
        New-ItemProperty -Path $strRegPath -Name "sysServices" -Value $intService -Force | Out-Null
        Write-Host "Services setted: $Services"

        # Set Permitted Managers
        $strRegPath = "$strSNMPRegPath\PermittedManagers"
        If ($Managers -ne "") {
            If ($Managers -ne "*") {
                # Delete all entries
                Remove-ItemProperty -Path $strRegPath -Name * -Force | Out-Null

                # Set managers
                $i = 1
                ForEach ($mgr in $Managers) {
                    New-ItemProperty -Path $strRegPath -Name "$i" -Value $mgr -Force | Out-Null
                    $i += 1
                }
                Write-Host "Manager setted: $Managers"
            }
            Else {
                # Delete all entries
                Remove-ItemProperty -Path $strRegPath -Name * -Force | Out-Null
                Write-Host "No Managers defined. Any hosts can accept SNMP packets"
            }
        }
    }
    catch {
        Write-Error "ERROR: Cannot Set SNMP Parameters! $($_.Exception.Message)"
    }
}


Function New-SNMPCommunity {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Name,
        [Parameter(Mandatory=$true)][String] $Rights
    )

    $strRegPath = "$strSNMPRegPath\ValidCommunities"

    Switch ($Rights) {
        "NONE" {$intValue = 1}
        "NOTIFY" {$intValue = 2}
        "READONLY" {$intValue = 4}
        "READWRITE" {$intValue = 8}
        "READCREATE" {$intValue = 16}
        default {$intValue = 4} #Default READONLY
    }

    try {
        # Create Community
        New-ItemProperty -Path $strRegPath -Name "$Name" -Value $intValue -Force | Out-Null
        Write-Host "Community setted: $Name"
        Write-Host "Community Rights setted: $Rights"
    }
    catch {
        Write-Error "ERROR: Cannot Set SNMP Communities! $($_.Exception.Message)"
    }
}

Function New-SNMPTrap {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Community,
        [Parameter(Mandatory=$true)][String] $ID,
        [Parameter(Mandatory=$true)][String] $Name
    )
    
    $strRegPath = "$strSNMPRegPath\TrapConfiguration\$Community"

    try {
        # Create the Trap Community
        If (!(Test-Path $strRegPath)) {
            New-Item -Path $strRegPath -Force | Out-Null
        }

        # Create the trap
        New-ItemProperty -Path $strRegPath -Name "$ID" -Value "$Name" -Force | Out-Null
        Write-Host "Trap setted: $Name (ID: $ID)"
    }
    catch {
        Write-Error "ERROR: Cannot Set SNMP Traps! $($_.Exception.Message)"
    }
}


Function Set-SNMPConfig {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)] $Data
    )

    # Parse the Hardware Node
    # Set SNMP parameters
    If ($Data.parameters -ne $null) {
        $Args = @{
            Contact = $Data.parameters.contact.name
            Location = $Data.parameters.location.name
            EnableAuthTraps = [Int]$Data.parameters.enableauthtraps.value
            NameResRetries = [Int]$Data.parameters.nameresretries.value
            Services = [array]($Data.parameters.service.list) -split ","
            Managers = [array]($Data.parameters.manager.list) -split ","
        }
        Set-SNMPParameters @Args
    }

    # Parse SNMP Communities
    ForEach ($com in $Data.communities.community) {
        $strComName = $com.name
        $strComRights = $com.rights
        # Create SNMP Community
        If (($strComName -ne "") -and ($strComRights -ne "")) {
            # Create the Community
            New-SNMPCommunity -Name $strComName -Rights $strComRights

            # Initialize the SNMP TrapConfiguration registry key to avoid SNMP error in the Event Log
            New-Item -Path "$strSNMPRegPath\TrapConfiguration" -Force | Out-Null

            # Parse SNMP Traps
            ForEach ($trap in $com.trap) {
                $strTrapID = $trap.id
                $strTrapName = $trap.name
                # Create SNMP Trap
                If (($strTrapID -ne "") -and ($strTrapName -ne "")) {
                    # Create the Trap
                    New-SNMPTrap -Community $strComName -ID $strTrapID -Name $strTrapName
                }
                Else {
                    Write-Host "No trap to create for $strComName Community."
                }
            }
        }
        Else {
            Write-Host "No SNMP Community to create."
        }
    }#ForEach
}


########
# MAIN #
########
# Set path of the XML file
$Global:xmlFile = "$PSScriptRoot\$File"

If (Test-Path $xmlFile) {
    $xmlNodeCommon = Get-SNMPConfig -Hardware "Common"
    $xmlNodeHardware = Get-SNMPConfig -Hardware "$tsenv:Make"
}
Else {
    Write-Error "ERROR: $File not exists! SNMP configuration aborted."
}


# Registry key path
$Global:strSNMPRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters"

# Check if the SNMP Service exists
If ((Get-Service -Name "SNMP" -ErrorAction SilentlyContinue) -ne $empty) {
    # Actions about Common Section
    If ($xmlNodeCommon -ne $null) {
        Set-SNMPConfig -Data $xmlNodeCommon
    }

    # Actions about Hardware Section
    If ($xmlNodeHardware -ne $null) {
        Set-SNMPConfig -Data $xmlNodeHardware
    }
}
Else {
    Write-Host "SNMP Service not exists. Nothing to do."
}
