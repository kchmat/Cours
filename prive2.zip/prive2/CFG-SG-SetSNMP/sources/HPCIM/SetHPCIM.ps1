# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.5 (14/03/05)
# // Developer: Florian Valente
# // 
# // Purpose:   Set HP CIM (only for HP Servers)
# //            Values are based on the SNMP configuration
# // Usage:     SetHPCIM.ps1
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $SMTPServer = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Reg = "HPCIMCustom.reg"
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path

# Set the From format (it can be customized)
$strOSVersion = ((Get-WmiObject -Class "Win32_OperatingSystem").Version).SubString(0,3)
$strOSSP = (Get-WmiObject "Win32_OperatingSystem").ServicePackMajorVersion
$strFrom = "$($env:COMPUTERNAME)-Win_$($strOSVersion)_$($tsenv:Architecture.ToLower())_SP$($strOSSP)_Server"


Function New-RegEntry {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Path,
        [Parameter(Mandatory=$true)][String] $Name,
        [Parameter(Mandatory=$true)] $Value
    )

    try {
        If (!(Test-Path $Path)) {
            New-Item -Path $Path -Force
        }
        Write-Host "Setting Key: $Path"
        New-ItemProperty -Path $Path -Name "$Name" -Value $Value -Force | Out-Null
        Write-Host "Data $Name setted: $Value"
    }
    catch {
        Write-Error "ERROR: Cannot Set $Path\$Name! $($_.Exception.Message)"
    }
}


########
# MAIN #
########
# Registry key source path
$strSNMPRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters"

# Registry key CIM path
$strCIMRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\CIMNotify\Parameters"

If ($tsenv:Make -eq "HP") {
    # Create the CIM Reg Values
    # FromAddress
    New-RegEntry -Path "$strCIMRegPath\FromAddress" -Name "Name" -Value $strFrom

    # SMTPHost
    If ($SMTPServer -ne "") { #In case of installation by Software Catalog
        New-RegEntry -Path "$strCIMRegPath\SmtpHost" -Name "Name" -Value $SMTPServer
    }
    ElseIf ($tsenv:SGSMTPServer -ne "") { #Variable available during a new deployment
        New-RegEntry -Path "$strCIMRegPath\SmtpHost" -Name "Name" -Value $tsenv:SGSMTPServer
    }
    Else {
        Write-Warning "WARNING: No SNMP Server found! Please configure $strCIMRegPath manually."
    }

    # ReplyTo
    $strValue = (Get-Item "$strSNMPRegPath\RFC1156Agent").GetValue("sysContact")
    If ($strValue.Contains("@")) {
        New-RegEntry -Path "$strCIMRegPath\ReplyTo" -Name "Name" -Value $strValue

        # Recip0
        # Address = ReplyTo
        New-RegEntry -Path "$strCIMRegPath\Recip0" -Name "Address" -Value $strValue

        # Name = ReplyTo without @ if exists
        $strValue = $strValue.Substring(0, $($strValue.LastIndexOf("@")))
        New-RegEntry -Path "$strCIMRegPath\Recip0" -Name "Name" -Value $strValue

        # ReceiverType
        New-RegEntry -Path "$strCIMRegPath\Recip0" -Name "ReceiverType" -Value 1
    }
    Else {
        Write-Warning "WARNING: SNMP Contact is not a mail address. Please configure $strCIMRegPath manually."
    }

    # Load the input reg file if exists
    $strRegFile = "$PSScriptRoot\$Reg"
    If (Test-Path $strRegFile) {
        Invoke-Expression -Command "regedit.exe /s '$strRegFile'"
        If (!$?) {
            Write-Error "$Reg not imported successfully!"
        }
        Else {
            Write-Host "$Reg imported successfully!"
        }
    }
    Else {
        Write-Warning "WARNING: File $strRegFile not found! Cannot configure HPCIM events"
    }

    # Change service CIMNotify startup type to Automatic
    If (Get-Service "CIMNotify" -ErrorAction SilentlyContinue) {
        Set-Service "CIMNotify" -StartupType Automatic
        If ($?) {
            Write-Host "Service CIMNotify setted to Automatic"
        }
    }
}
Else {
    Write-Host "It's not an HP Server. Nothing to do."
}



