# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (16/01/22)
# // Developer: Florian Valente
# // 
# // Purpose:   Set NTP Server
# // Usage:     SetNTP.ps1 -File <confFile.xml>
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $File
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Get-NTPServersFromFile {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Path
    )

    If (!(Test-Path $Path)) {
        Write-Error "$Path not exists! NTP configuration aborted."
    }

    # Parse XML
    $xml = [xml](Get-Content $Path)

    return $xml.configuration.ntp.name
}


Function Set-NTPServer {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)] $List
    )

    $strNTPServers = ""
    $strNTPExe = "w32tm.exe"

    # Parse NTP Servers list found in the XML file
    $List | % {
        # Get server's DNS suffix
        $strDNSSuffix = ""
        If (!([String]::IsNullOrEmpty($tsenv:SGDNSSuffix))) {
            $strDNSSuffix = $tsenv:SGDNSSuffix
        }
        Else {
            $strDNSSuffix = ([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()).DomainName
        }

        # If #DNSSUFFIX# found in the NTP server name, add the DNS Suffix
        If (($_ -match "#DNSSUFFIX#") -and ($strDNSSuffix -ne "")) {
            $strServer = $_ -replace "#DNSSUFFIX#", ".$strDNSSuffix"
        }
        Else {
            $strServer = $_
        }

        # If server ping, add it to the list
        If (Ping-Machine -Name $strServer) {
            $strNTPServers += "$strServer "
        }
        Else {
            Write-Host "$strServer is unreachable. Skip"
        }
    }

    #Remove space at the end of string
    $strNTPServers = $strNTPServers.Trim()

    If ($strNTPServers -ne "") {
        Write-Host "NTP List: $strNTPServers"
        # For OS < Win2012, need to add 0x8
        If ((Get-OSVersion) -lt 6.3) {
            $strArgs = "/config /manualpeerlist:""$strNTPServers"",0x8 /syncfromflags:MANUAL"
        }
        Else {
            $strArgs = "/config /manualpeerlist:""$strNTPServers"" /syncfromflags:MANUAL"
        }

        # Run the command
        try {
            Start-Custom -Value "$strNTPExe $strArgs"
            Write-Host "NTP configuration updated successfully"
        }
        catch {
            Write-Error "Cannot set NTP! $($_.Exception.Message)"
        }

        # Windows Time Service must be running before configuring time with w32tm.exe
        If ((Get-Service W32Time).Status -ne "Running") {
            Start-Service W32Time
            Write-Host "Service Windows Time is running"
        }

        try {
            Start-Custom -Value "$strNTPExe /configure /update"
            Write-Host "NTP configured successfully"
        }
        catch {
            Write-Error "Cannot configure NTP! $($_.Exception.Message)"
        }
    }
    Else {
        Write-Warning "No NTP Server reachable. Please set NTP manually"
    }
}


########
# MAIN #
########
# Set path of the XML file
$xmlFile = "$PSScriptRoot\$File"

If ((Test-JoinDomain) -eq $false) {
    Write-Host "Server is in WORKGROUP, setting NTP Server(s)..."
    $NTPServers = Get-NTPServersFromFile -Path $xmlFile
    If ($NTPServers -eq $null) {
        Write-Host "No NTP Server found in $xmlFile! Nothing to do."
        Exit
    }

    Set-NTPServer -List $NTPServers
}
Else {
    Write-Host "Server is joined to a domain. Nothing to do."
}


