# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (14/01/20)
# // Developer: Florian Valente
# // 
# // Purpose:   Disable all Net Adapters except the active
# // Usage:     DisableNetAdapters.ps1 -<args>
# //            Args:
# //            [-All]: Disable all network adapters except the active (otherwise it's all disconnected)
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $All = $false
)

# Get the active MAC Address
#$strActiveMacAddress = $tsenv:OSDAdapter0MacAddress -replace ":", "-"
# Cannot use MAC Address because could not be the first net adapter found

# Get the active Gateway Address
# DO NOT USE OSDAdapter0Gateways variable
#$strActiveGatewayAddress = $tsenv:DefaultGateway001

try {
    # Get all physical adapters not setted with the active gateway
    #$oNetAdapters = Get-NetIPConfiguration | Where-Object {$_.IPv4DefaultGateway.NextHop -ne $strActiveGatewayAddress}
    $oNetAdapters = Get-NetIPConfiguration | Where-Object {$_.IPv4DefaultGateway.NextHop -eq $null}

    If (!($All)) {
        # Get all adapters disconnected
        $oNetDown = $oNetAdapters | Where-Object {$_.NetAdapter.Status -eq "Disconnected"}
        Write-Host "Disabling $(($oNetDown | Measure-Object).Count) Network Adapters which are disconnected."

        $oNetDown | Disable-NetAdapter -Confirm:$false
    }
    Else {
        Write-Host "Disabling all Net Adapters without gateway setted..."
        $oNetAdapters | Disable-NetAdapter -Confirm:$false
    }

    Write-Host "Network Adapters disabled successfully!"

    # If several net adapters are detected (more than 1), display a warning.
    # In a normal Master Deployment, only one net adapter should be activated.
    $count = ((Get-NetAdapter) | Where-Object {$_.State -eq 2} | Measure-Object).Count
    If ($count -eq 0) {
        Write-Warning "All Network Adapters are disabled! Check your IP configuration"
    }
    ElseIf ($count -gt 1) {
        If ((Get-NetLbfoTeam) -eq $null) {
            # If no teaming detected by several network adapters are enabled: Display a warning
            Write-Warning "Several Network Adapters are enabled. Check the configuration"
        }
    }
}
catch {
    Write-Error "ERROR: Network Adapters not disabled successfully. $($_.Exception.message)"
}