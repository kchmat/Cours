# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (15/02/12)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Network Providers
# // Usage:     SetNetworkProviders.ps1 -File <confFile.xml>
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $File
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Get-NetProvidersFromFile {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Path
    )

    If (!(Test-Path $Path)) {
        Write-Error "$Path not exists! Network Providers configuration aborted."
    }

    # Parse XML
    $xml = [xml](Get-Content $Path)

    return $xml.providers.provider.name
}


Function Get-NetProvidersFromRegistry {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Path
    )

    If (!(Test-Path $Path)) {
        Write-Warning "$Path not exists! Network Providers configuration aborted."
        return $null
    }

    Write-Host "Getting Network Providers from $Path..."

    $arrNetProviders = ((Get-ItemProperty -Path $Path).ProviderOrder -split ",").Trim()
    If ($arrNetProviders[0] -eq "") {
        Write-Host "No Providers found in the Registry Key. Nothing to do."
        return $null
    }
    Else {
        Write-Host "Providers found: $($arrNetProviders -join ",")"
        return $arrNetProviders
    }
}


Function Set-NetProviders {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true)][String] $Path,
        [Parameter(Mandatory=$true)] $Providers
    )

    $LocalNetProviders = Get-NetProvidersFromRegistry -Path $Path

    If ($LocalNetProviders -ne $null) {
        Write-Host "Updating Network Providers..."
        # Initialize the Provider's array
        $arrProviders = @()
        $Providers | % {
            If ($LocalNetProviders.ToLower().Contains($_.ToLower())) {
                $arrProviders += @($_)
                Write-Host "$_ added"
            }
            Else {
                Write-Host "$_ not exists in the registry Provider's list. Skip"
            }
        }

        # Add to the Provider's array providers which are not specified in the XML file but in the registry
        $LocalNetProviders | % {
            If (!($arrProviders.ToLower().Contains($_.ToLower()))) {
                $arrProviders += @($_)
                Write-Host "$_ added"
            }
        }

        try {
            $Result = $arrProviders -join ","
            Set-ItemProperty -Path $Path -Name "ProviderOrder" -Value $Result -Type "String" -Force | Out-Null
            Write-Host "Network Providers Order updated successfully. (Order: $Result)"
        }
        catch {
            Write-Error "Cannot update Network Providers Oder! $($_.Exception.Message)"
        }
    }
    
}


########
# MAIN #
########
# Set path of the XML file
$xmlFile = "$PSScriptRoot\$File"

$NetProviders = Get-NetProvidersFromFile -Path $xmlFile
If ($NetProviders -eq $null) {
    Write-Error "Cannot get Network Providers from $xmlFile! Please check XML File content"
}

Set-NetProviders -Path "HKLM:\SYSTEM\CurrentControlSet\Control\NetworkProvider\Order" -Providers $NetProviders
Set-NetProviders -Path "HKLM:\SYSTEM\CurrentControlSet\Control\NetworkProvider\HwOrder" -Providers $NetProviders

