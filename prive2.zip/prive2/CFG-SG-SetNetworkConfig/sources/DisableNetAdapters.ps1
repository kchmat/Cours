# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   2.0 (14/07/11)
# // Developer: Florian Valente
# // 
# // Purpose:   Disable all Net Adapters except the active
# // Usage:     DisableNetAdapters.ps1 -<args>
# //            Args:
# //            [-All]: Disable all network adapters except the active (otherwise it's all disconnected)
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $All = $false
)


Function Disable-NetAdapterByWMI {
    try {
        # Get all adapters disconnected
        $oNetDown = Get-WmiObject -Class Win32_NetworkAdapter -Filter "NetConnectionStatus=7"
        Write-Host "Disabling $(($oNetDown | Measure-Object).Count) Network Adapters which are disconnected."
        $oNetDown | % { $_.disable() | Out-Null }

        If ($All) {
            # Get all physical adapters not setted with the active gateway
            $oNetDown = Get-WmiObject -Class Win32_NetworkAdapter -Filter "NetEnabled=true"
            Write-Host "Disabling all Net Adapters except the active one..."
            $oNetDown | % {
                If ($_.MACAddress -ne "$tsenv:MACAddress001") { $_.disable() | Out-Null } 
            }
        }

        Write-Host "Network Adapters disabled successfully!"
    }
    catch {
        Write-Error "ERROR: Network Adapters not disabled successfully. $($_.Exception.message)"
    }
}


Function Disable-NetAdapterByPS {
    try {
        # Get all physical adapters not setted with the active gateway
        $oNetAdapters = Get-NetIPConfiguration | Where-Object {$_.IPv4DefaultGateway.NextHop -eq $null}

        If (!($All)) {
            # Get all adapters disconnected
            $oNetDown = $oNetAdapters | Where-Object {$_.NetAdapter.Status -eq "Disconnected"}
            Write-Host "Disabling $(($oNetDown | Measure-Object).Count) Network Adapters which are disconnected."

            $oNetDown | Disable-NetAdapter -Confirm:$false
        }
        Else {
            Write-Host "Disabling all Net Adapters without gateway setted..."
            $oNetAdapters | Disable-NetAdapter -Confirm:$false
        }

        Write-Host "Network Adapters disabled successfully!"

        # If several net adapters are detected (more than 1), display a warning.
        # In a normal Master Deployment, only one net adapter should be activated.
        $count = ((Get-NetAdapter) | Where-Object {$_.State -eq 2} | Measure-Object).Count
        If ($count -eq 0) {
            Write-Warning "All Network Adapters are disabled! Check your IP configuration"
        }
        ElseIf ($count -gt 1 -and $All) {
            Write-Warning "Several Network Adapters are enabled. Check the configuration"
        }
    }
    catch {
        Write-Error "ERROR: Network Adapters not disabled successfully. $($_.Exception.message)"
    }
}



########
# MAIN #
########
If ((Get-OSVersion) -lt 6.3) {
    Write-Host "Old OS detected. using WMI..."
    Disable-NetAdapterByWMI
}
Else {
    Disable-NetAdapterByPS
}