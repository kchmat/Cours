# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (13/07/31)
# // Developer: Florian Valente
# // 
# // Purpose:   Priorize the IPv6 Protocol after IpV4
# // Usage:     SetIPv6.ps1
# // ***************************************************************************

$strRegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\TCPIP6\Parameters"
$strRegName = "DisabledComponents"
$strRegValue = 32 # Priorize IPv4 on IPv6

New-ItemProperty -Path $strRegPath -Name $strRegName -Value $strRegValue -Force | Out-Null
If (!$?) {
    Write-Error "ERROR: Cannot modify $strRegName in $strRegPath!"
}
Else {
    Write-Host "IPv4 priorized on IPv6"
}
