# // ***************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   3.0 (15/02/10)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Network Configuration
# //             Disable/Enable specific network components like IPv6, QoS Packet Scheduler,
# //             LL Topology Discovery Mapper, LL Topology Discovery Responder
# //             File and Printer Sharing for Microsoft Networks, Client for Microsoft Networks
# //             WINS Client(TCP/IP) Protocol, Point to Point Protocol Over Ethernet
# //            Set state of Registration of connection's addresses in DNS
# //            Set state of NetBIOS over TCP/IP
# //            Set state of Power Management (Allow the computer to turn off this device to save power)
# // Usage:     SetNetworkConfig.ps1 -<args>
# //            Args:
# //            [-DisabledComponent]: Disable components (QoS, IPv6, LLTDIO, LLTDR, MSCLIENT, MSSHARE, NETBT, PPPOE)
# //            [-EnabledComponent]: Enable components (QoS, IPv6, LLTDIO, LLTDR, MSCLIENT, MSSHARE, NETBT, PPPOE)
# //            [-RegisterDNS]: If present, disable or enable registration of connection's addresses in DNS
# //            [-TcpipNetBIOS]: Default or Enabled or Disabled. State of NetBIOS over TCP/IP
# //            [-PowerMgmt]: If present, disable or enable Power Management
# // ***************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("QoS", "IPv6", "LLTDIO", "LLTDR", "MSCLIENT", "MSSHARE", "NETBT", "PPPOE")] $DisabledComponent = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("QoS", "IPv6", "LLTDIO", "LLTDR", "MSCLIENT", "MSSHARE", "NETBT", "PPPOE")] $EnabledComponent = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Enabled", "EnabledAll", "Disabled")][String] $RegisterDNS = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Default", "Enabled", "Disabled")][String] $TcpipNetBIOS = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("Enabled", "Disabled")][String] $PowerMgmt = ""
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Set-NetComponents {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)] $Components,
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $Disable = $false
    )

    # Set Nvspbind tool path
    # http://blogs.technet.com/b/jhoward/archive/2010/01/25/announcing-nvspbind.aspx
    $strToolPath = "$PSScriptRoot\nvspbind.exe"

    If (!(Test-Path $strToolPath)) {
        Write-Error "ERROR: nvspbind.exe not found! Exit"
    }

    try {
        If ($Disable) {
            $strNvspbindOption = "-d"
            $strComponentStatus = "DISABLED"
        }
        Else {
            $strNvspbindOption = "-e"
            $strComponentStatus = "ENABLED"
        }

        foreach ($component in $Components) {
            # Intentionally not added some components like NetBios, smb, TCPIPv4
            Switch ($component) {
                "QoS" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_pacer" -Wait
                    Write-Host "Component ""QoS Packet Scheduler"" $strComponentStatus successfully"
                }
                "IPv6" {
                    # DISABLE TCP/IPv6 IS NOT SUPPORTED BY MICROSOFT
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_tcpip6" -Wait
                    Write-Host "Component ""Internet Protocol Version 6 (TCP/IPv6)"" $strComponentStatus successfully"
                }
                "LLTDIO" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_lltdio" -Wait
                    Write-Host "Component ""Link-Layer Topology Discover Mapper I/O Driver"" $strComponentStatus successfully"
                }
                "LLTDR" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_rspndr" -Wait
                    Write-Host "Component ""Link-Layer Topology Discovery Responder"" $strComponentStatus successfully"        
                }
                "MSCLIENT" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_msclient" -Wait
                    Write-Host "Component ""Client for Microsoft Networks"" $strComponentStatus successfully" 
                }
                "MSSHARE" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_server" -Wait
                    Write-Host "Component ""File and Printer Sharing for Microsoft Networks"" $strComponentStatus successfully" 
                }
                "NETBT" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_netbt" -Wait
                    Write-Host "Component ""WINS Client(TCP/IP) Protocol"" $strComponentStatus successfully" 
                }
                "PPPOE" {
                    Start-Process "$strToolPath" -ArgumentList "$strNvspbindOption * ms_pppoe" -Wait
                    Write-Host "Component ""Point to Point Protocol Over Ethernet"" $strComponentStatus successfully" 
                }
            }
        }
    }
    catch {
        Write-Error "Component not $strComponentStatus. $($_.Exception.message)"
    }
}

########
# MAIN #
########
# Configure Network Adapter Components
Write-Host "Configuring Network Adapter Components..."
If ($DisabledComponent -ne "") {
    Set-NetComponents -Components $DisabledComponent -Disable
}
If ($EnabledComponent -ne "") {
    Set-NetComponents -Components $EnabledComponent
}
Write-Host "Network Adapter Components configured successfully"


## Configure Registration of connection's addresses in DNS
If ($RegisterDNS -ne "") {
    Write-Host "Configuring registration of connection's addresses in DNS..."
    Switch ($RegisterDNS) {
        "Enabled" { $boolFullDNSReg = $true; $boolDomainDNSReg = $false }
        "Disabled" { $boolFullDNSReg = $false; $boolDomainDNSReg = $false }
        "EnabledAll" { $boolFullDNSReg = $true; $boolDomainDNSReg = $true }
    }
    try {
        (Get-WmiObject Win32_NetworkAdapter -Filter "NetEnabled=True").GetRelated('Win32_NetworkAdapterConfiguration') | % {
            $strAdapterName = $_.Description
            # https://msdn.microsoft.com/en-us/library/aa393298(v=vs.85).aspx
            $Result = $_.SetDynamicDNSRegistration($boolFullDNSReg, $boolDomainDNSReg)
            Switch ($Result.ReturnValue) {
                96 { Write-Host "$($strAdapterName): Unable to notify DNS service." }
                Default { Write-Host "$($strAdapterName): $($RegisterDNS.ToUpper()) configured successfully (Return Code: $($Result.ReturnValue))" }
            }
        }        
    }
    catch {
        Write-Error "Cannot $($RegisterDNS.ToUpper()) registration of connection's addresses in DNS. $($_.Exception.message)"
    }
} #End If


## Configure Status of NetBIOS over TCP/IP
If ($TcpipNetBIOS -ne "") {
    Write-Host "Configuring NetBIOS over TCP/IP..."
    try {
        Switch ($TcpipNetBIOS) {
            "Default" {$intValue = 0} # Enable Netbios via DHCP
            "Enabled" {$intValue = 1} # Enable Netbios
            "Disabled" {$intValue = 2} # Disable Netbios
        }

        (Get-WmiObject Win32_NetworkAdapter -Filter "NetEnabled=True").GetRelated('Win32_NetworkAdapterConfiguration') | % {
            $strAdapterName = $_.Description
            # https://msdn.microsoft.com/en-us/library/aa393601%28v=vs.85%29.aspx
            $Result = $_.SetTcpipNetbios($intValue)
            Switch ($Result.ReturnValue) {
                100 { Write-Host "$($strAdapterName): DHCP not enabled on adapter. Nothing to do." }
                Default { Write-Host "$($strAdapterName): $($TcpipNetBIOS.ToUpper()) configured successfully (Return Code: $($Result.ReturnValue))" }
            }
        }
    }
    catch {
        Write-Error "Cannot configure NetBIOS over TCP/IP. $($_.Exception.message)"
    }
} #End If


## Configure Power Management (Allow the computer to turn off this device to save power)
# http://support.microsoft.com/kb/2740020
If ($PowerMgmt -ne "") {
    Write-Host "Configuring Power Management on enabled Network Adapters..."
    Switch ($PowerMgmt) {
        "Enabled" { $intPowerMgmt = 0 }
        "Disabled" { $intPowerMgmt = 24 }
    }

    Get-WmiObject Win32_NetworkAdapter -Filter "NetEnabled=True" | % {
        # Check the unique device id number of network adapter in the currently environment
        If([Int32]$_.DeviceID -lt 10) { $AdapterDeviceNumber = "000" + $_.DeviceID }
		Else { $AdapterDeviceNumber = "00" + $_.DeviceID }

        $KeyPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}\$AdapterDeviceNumber"
        # Check whether the registry path exists
        If(Test-Path -Path $KeyPath) {
            Write-Host "$($_.Name): Registry Key: $KeyPath"
			$PnPCapabilitiesValue = (Get-ItemProperty -Path $KeyPath).PnPCapabilities
			
            If ($PnPCapabilitiesValue -eq 24) {
                Write-Host "$($_.Name): Old value info: Disabled."
            }
            ElseIf (($PnPCapabilitiesValue -eq 0) -or ($PnPCapabilitiesValue -eq $null)) {
                Write-Host "$($_.Name): Old value info: Enabled."
            }
            Else {
                Write-Host "$($_.Name): Old value info: Unknown ($PnPCapabilitiesValue)."
            }

            try {	
	            # Set the value of properties of PnPCapabilites, 24 will disable save power option
	            New-ItemProperty -Path $KeyPath -Name "PnPCapabilities" -Value "$intPowerMgmt" -PropertyType DWord -Force | Out-Null
	            Write-Host "$($_.Name): Power Management $($PowerMgmt.ToUpper()) successfully. Need a restart to be applied."
            }
            catch {
	            Write-Warning "$($_.Name): Cannot $($PowerMgmt.ToUpper()) ""Allow the computer to turn off this device to save power"". $($_.Exception.Message)"
            }
		}
		Else {
			Write-Warning "The Network Adapter's Registry Path ($KeyPath) was not found."
		}
    } #End ForEach
} #End If
