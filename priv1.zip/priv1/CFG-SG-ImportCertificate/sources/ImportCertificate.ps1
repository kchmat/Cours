# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (15/08/04)
# // Developer: Florian Valente
# // 
# // Purpose:   Import certificate
# // Usage:     ImportCertificate.ps1
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Path,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Store = "Root",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $Force
)

$ErrorActionPreference = 'Stop'

##################################################
##               GLOBAL VARIABLES               ##
##################################################
# Accepted certificate extensions
$strAcceptedExtension = @("sst","cer","cert","p7b","crt")

# Certificate Store base path
$strStorePath = "Cert:\LocalMachine"


##################################################
##               Functions and Subs             ##
##################################################
Function Import-CustomCertificate {
    [CmdletBinding()]
    PARAM (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $FilePath,
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $StoreLocation
    )

    If (Test-Path $FilePath) {
        $FileName = Split-Path $FilePath -Leaf
        Write-Host "Importing certificate $FileName on $StoreLocation..."
        If ((Get-OSVersion) -ge 6.3) {
            try {
                Import-Certificate -FilePath "$FilePath" -CertStoreLocation "$strStorePath\$StoreLocation"
                Write-Host "Certificate imported successfully"
            }
            catch {
                Write-Warning "Cannot import $FileName certificate ($($_.Exception.Message))"
            }
        }
        Else {
            try {
                If ((Get-ItemProperty $FilePath).Extension -eq ".sst") {
                    Write-Host "Serialized Store Certificate (sst) File found. Processing..."
                    [Reflection.Assembly]::LoadWithPartialName("System.Security")
                    $certs = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                    $certs.Import("$FilePath")
                    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store -argumentlist "$StoreLocation", LocalMachine
                    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]"ReadWrite")
                    $store.AddRange($certs)
                    Write-Host "Certificate imported successfully"
                }
                Else {
                    Write-Host "Using certutil..."
                    $objStatus = Start-Process -FilePath "certutil.exe" -ArgumentList "-addstore -f $StoreLocation ""$FilePath""" -PassThru -Wait
                    If ($objStatus.ExitCode -eq 0) {
                        Write-Host "Certificate imported successfully"
                    }
                    Else {
                        Write-Warning "Cannot import $FileName certificate. Certutil exit code: $($objStatus.ExitCode) ($($objStatus.Description))" 
                    }
                }
            }
            catch {
                Write-Warning "Cannot import $FileName certificate ($($_.Exception.Message))"
            }
        }
    }
    Else {
        Write-Host "$FilePath not found. Nothing to do"
    }
}



##################################################
##                     MAIN                     ##
##################################################
If ((!($Force)) -and ((Test-JoinDomain) -eq $true)) {
    # Access denied issue encountered when trying to import sst cert on a server joined to a domain
    Write-Host "Server is joined to a domain. Exit"
    exit
}

$Path = "$PSScriptRoot\$Path"
Write-Host "Getting certificate(s) in $Path..."
If (Test-Path $Path) {
    If ((Get-ItemProperty $Path) -is [System.IO.DirectoryInfo]) {
        # If folder set in parameter, get all files corresponding to accepted extensions
        $objCerts = Get-ChildItem $Path | ? {[System.IO.Path]::GetExtension($_) -match ($strAcceptedExtension -join "|")}
    }
    Else {
        # If file set in parameter, get file if corresponding to accepted extensions
        $objCerts = Get-ItemProperty $Path | ? {$_.Extension -match ($strAcceptedExtension -join "|")}
    }

}

If ($objCerts.Count -eq 0) {
    Write-Host "No certificate found in the path. Nothing to do"
    Exit
}

If (!(Test-Path "$strStorePath\$Store")) {
    Write-Error "Certificate Store ""$Store"" doesn't exist!"
}

Write-Host "$($objCerts.Count) certificate(s) found! Importing..."
$objCerts | % {
    Import-CustomCertificate -FilePath $_.FullName -StoreLocation $Store
}

Write-Host "Import done"