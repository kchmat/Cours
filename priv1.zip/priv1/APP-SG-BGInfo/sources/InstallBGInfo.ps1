# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (17/02/15)
# // Developer: Florian Valente
# //			Pierre BOUSSINGAULT
# // 
# // Purpose:   Install BGInfo
# // Usage:     InstallBGInfo.ps1 -<args>
# //            Args:
# //            -ConfFile: Used Configuration file
# // 			-Version: Binary version used (don't forget to update bgi file to be compatible)
# //            [-TeamResponsible]: Specify the team responsible of the server in BGInfo
# //            [-Owner]: Specify the server owner in BGInfo
# //            [-SyncFile]: Specify the URL Marley synchronization file
# // ***********************************************************************************************************

[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $BinPath,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile,
	[Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Version,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $TeamResponsible = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Owner = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $SyncFile = "",
	[Parameter(Mandatory=$false,ValueFromPipeline=$true)][Boolean] $AWS = $false
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Test-CitrixServer {
    $strRegKey = "HKLM:\SYSTEM\CurrentControlSet\Services\IMAService"
    $strDesc = (Get-ItemProperty -Path $strRegKey -ErrorAction SilentlyContinue).Description
    If ($strDesc -eq "Provides management services for Citrix products") {
        Write-Host "CITRIX is installed on this server"
        return $true
    }
    Else {
        return $false
    }
}



Function Uninstall-BGInfo {
    Write-Host "Uninstalling BGInfo..."
    try {
        Remove-Item -Path "$strBGIPath" -Recurse -Force
        Remove-Item -Path "$env:ALLUSERSPROFILE\Start Menu\Programs\Startup\BgInfoStartup.lnk" -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "$strRegBGIPath" -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "BGInfo uninstalled successfully"
    }
    catch {
        Write-Error "ERROR: Uninstallation failed! $($_.Exception.Message)"
    }
}


Function Install-BGInfo {
    Write-Host "Installing BGInfo in $strBGIPath..."
    try {
        # Copy BGInfo Sources
        New-Item -Path "$strBGIPath" -ItemType directory -Force | Out-Null
        Copy-Item "$strBGISourcesPath\*" -Destination "$strBGIPath" -Force
		Copy-Item "$strBGIConfigPath\*" -Destination "$strBGIPath" -Force
		
        # Copy BGInfo ConfFile in config folder
        New-Item -Path "$strBGIPath\config" -ItemType directory -Force | Out-Null
        Move-Item "$strBGIPath\$ConfFile" -Destination "$strBGIPath\config" -Force
        Write-Host "$strBGIPath\config\$ConfFile will be used by BGInfo"

        # If Citrix server, do not launch BGInfo at startup
        If (((Test-CitrixServer) -eq $false) -or ($tsenv:SGRole -notmatch "citrix|xenapp")) {
            # Create shortcut to launch BGInfo at startup
            $WshShell = New-Object -ComObject WScript.Shell
            $scPath = "$env:ALLUSERSPROFILE\Start Menu\Programs\Startup\BgInfoStartup.lnk"
            $sc = $WshShell.CreateShortcut($scPath)
            $sc.TargetPath = "$env:SystemRoot\System32\wscript.exe"
            $sc.Arguments = "/nologo /b ""$strBGIPath\BgInfoStartup.vbs"" $ConfFile"
            $sc.IconLocation = """$strBGIPath\BGInfo.exe"",1"
            $sc.WorkingDirectory = "$strBGIPath"
            $sc.Save()
            Write-Host "Shortcut created successfully in Startup folder"
        }
        Else {
            Write-Host "This is a Citrix server. BGInfo not launched at startup"
        }
        Write-Host "BGInfo installed successfully"
    }
    catch {
        Write-Error "ERROR: Installation failed! $($_.Exception.Message)"
    }
}


Function Set-BGIRegistry {
    # Registry key path
    $strRegistryPath = "HKLM:\SOFTWARE\SG\System"
    If (!(Test-Path $strRegistryPath)) {
        New-Item -Path $strRegistryPath -Force | Out-Null
        If (!$?) {
            Write-Error "ERROR: Cannot create $strRegistryPath!"
        }
    }

    # Hash Table containing registry keys to add
    # Initialization
    $global:tRegHash = @{}
    $tRegHash.Add("ITECBL", " ")
    $tRegHash.Add("TeamResponsible", "$TeamResponsible")
    $tRegHash.Add("Location", " ")
    $tRegHash.Add("Cabinet", " ")
    $tRegHash.Add("Environments", "Not into Marley DB")
    $tRegHash.Add("App", " ")
    $tRegHash.Add("Owner", "$Owner")
	$tRegHash.Add("Version", "$Version")
	If ($AWS) {
		# new values for AWS EC2 instance
		$tRegHash.Add("instanceId", "$instanceId")
		$tRegHash.Add("amiId", "$amiId")
		$tRegHash.Add("instanceSize", "$instanceSize")
		$tRegHash.Add("availabilityzone", "$availabilityzone")
		$tRegHash.Add("securitygroups", "$securitygroups")
	}
    If ($SyncFile -ne "") {$tRegHash.Add("SyncFile", "$SyncFile")}

    $tRegHash.GetEnumerator() | % {
        $KeyName = $strRegistryPath + "\"
        New-ItemProperty -Path $KeyName -Name "$($_.Key)" -Value "$($_.Value)" -Force | Out-Null
        If (!$?) {
            Write-Error "ERROR: Cannot create $($_.Key)!"
        }
        Else {
            Write-Host "$($_.Key) added"
        }
    }
}

Function Get-AWSRegistryValues{
	Write-Host "Getting AWS registry values..."
	Try {
		$instanceId = ( Invoke-WebRequest -Uri http://169.254.169.254/latest/meta-data/instance-id -Method GET -TimeoutSec 2).Content
		$amiId = ( Invoke-WebRequest -Uri http://169.254.169.254/latest/meta-data/ami-id -Method GET -TimeoutSec 2).Content
		$instanceSize = ( Invoke-WebRequest -Uri http://169.254.169.254/latest/meta-data/instance-type -Method GET -TimeoutSec 2).Content
		$availabilityzone = ( Invoke-WebRequest -Uri http://169.254.169.254/latest/meta-data/placement/availability-zone -Method GET -TimeoutSec 2).Content
		$securitygroups = ( Invoke-WebRequest -Uri http://169.254.169.254/latest/meta-data/security-groups -Method GET -TimeoutSec 2).Content
	}
	Catch {
		$instanceId = ""
		$amiId = ""
		$instanceSize =""
		$availabilityzone = ""
		$securitygroups =""
	}
}

########
# MAIN #
########
# Set path of BGInfo binaries
$Global:strBGIPath = "$env:ProgramFiles\BGInfo"

# Set registry path of BGInfo informations
$Global:strRegBGIPath = "HKLM:\SOFTWARE\SG\System"

# Set BGInfo sources path
$Global:strBGISourcesPath = "$PSScriptRoot\$Version"
If (!(Test-Path "$strBGISourcesPath\BGInfo.exe")) {
    Write-Error "ERROR: BGInfo sources not found!"
}

# Set BGInfo config path
$Global:strBGIConfigPath = "$PSScriptRoot\$BinPath"
If (!(Test-Path "$strBGIConfigPath\$ConfFile")) {
    Write-Error "ERROR: $ConfFile not found!"
}

# Uninstall previous version of BGInfo if exists
If (Test-Path -Path $strBGIPath) {
    Uninstall-BGInfo
}

# Install BGinfo
Install-BGInfo

# Configure AWS
If ($AWS) {
	Get-AWSRegistryValues
}

# Set registry
Set-BGIRegistry
