<#
.SYNOPSIS
	Apply Windows Updates available on the WSUS Server configured

.DESCRIPTION
	Apply Windows Updates available on the WSUS Server configured
    Or on the WSUS Server set in parameter. This server is used only if no WSUS Server is already set

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (2015/03/05)
    ChangeLog: 1.0 (2015/03/05)

.INPUTS
	URL: URL of the WSUS Server

.OUTPUTS
	None
	
.PARAMETER URL
	Set the URL of the WSUS Server (optional)
	
.EXAMPLE
	./UpdateServer.ps1

	./UpdateServer.ps1 -URL "http://wsus.socgen"

#>
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $URL = ""
)

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################
# Get Conf folder
$PSConfPath = "$PSScriptRoot\conf"

# Import Module PSWindowsUpdate
# https://gallery.technet.microsoft.com/scriptcenter/2d191bcd-3308-4edd-9de2-88dff796b0bc
Import-Module "$PSScriptRoot\PSWindowsUpdate" -Force | Out-Null


##################################################
##               Functions and Subs             ##
##################################################
Function Set-WUA {
    # http://www.windowsnetworking.com/articles-tutorials/windows-xp/Registry-Keys-Tweaking-Windows-Update-Part1.html
    # http://www.windowsnetworking.com/articles-tutorials/windows-xp/Registry-Keys-Tweaking-Windows-Update-Part2.html

    Write-Host "Initializing Windows Update Agent..."
    # Ensure the desired tracing registry entries are in place
    #Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Trace\Level" -KeyValue 3 -KeyType "DWord"
    #Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Trace\Handler\Flags" -KeyValue 0xh000000ff -KeyType "DWord"
    #Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Trace\Handler\Level" -KeyValue 3 -KeyType "DWord"
    #Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Trace\COMAPI\Flags" -KeyValue 0xh000000ff -KeyType "DWord"
    #Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Trace\COMAPI\Level" -KeyValue 3 -KeyType "DWord"

    # Configure the WSUS server in the registry.  This needs to be a URL (e.g. http://myserver).
    Write-Host "Configuring client to use WSUS server $URL..."
    Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\WUServer" -KeyValue "$URL" -KeyType "String"
    Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\WUStatusServer" -KeyValue "$URL" -KeyType "String"

	Write-Host "Configuring Windows Update settings (manual update, use server)..."
    Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\UseWUServer" -KeyValue 1 -KeyType "DWord"
    Start-Registry -Action "add" -KeyName "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU\NoAutoUpdate" -KeyValue 0 -KeyType "DWord"

	# Restart the service to get the latest settings
    Write-Host "Restarting wuauserv Service..."
    Stop-Service -Name wuauserv -Force
    Start-Service -Name wuauserv -Confirm:$false

    Write-Host "Windows Update Agent initialized successfully"
}



##################################################
##                     MAIN                     ##
##################################################
# Get WU Service Managers which are not Windows Update (SID: 9482f4b4-e343-43b6-b170-9a65bc822c77) or Microsoft Update (SID: 7971f918-a847-4430-9279-4a52d1efe18d)
$WUServiceManager = Get-WUServiceManager | ? {$_.ServiceID -notmatch "9482f4b4-e343-43b6-b170-9a65bc822c77|7971f918-a847-4430-9279-4a52d1efe18d"}
If ($WUServiceManager -eq $null) {
    If (!([String]::IsNullOrEmpty($URL))) {
        Set-WUA
    }
    Else {
        Write-Warning "No WUS configured! Cannot update server"
        Exit
    }
}
Else {
    Write-Host "A WUS Server was found"
}

# Search and apply Windows Updates
try {
    Write-Host "Installing Windows Updates..."
    $oUpdates = Get-WUInstall -Confirm:$false -AcceptAll -IgnoreReboot

    # Display installed updates in the log
    $oUpdates | % {
        If ($_.Status -eq "Installed") {
            Write-Host $_.Title
        }
    }

    If (Get-WURebootStatus -Silent) {
        Write-Warning "Windows Updates applied successfully BUT restart is needed!"
    }
    Else {
        Write-Host "Windows Updates applied successfully! No restart needed"
    }
}
catch {
    Write-Error "Error during Windows Update Processing! $($_.Exception.Message)"
}



