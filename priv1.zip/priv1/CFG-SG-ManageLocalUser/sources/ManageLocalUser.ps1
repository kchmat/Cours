<#
.SYNOPSIS
	Manage Local Account

.DESCRIPTION
	This script is used to manage local account.
    It's possible to add or remove an account,
    define a scope of action; if it has to be created on workgroup, domain environment
    add it to local group(s),
    set if the password never expires
    set if the password cannot be changed

.LINK
	https://gallery.technet.microsoft.com/Local-Account-Management-a777191b
    + Bugfix in New-LocalUser about setting password when password restriction policy is defined

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (15/04/02)
    ChangeLog: 1.0 (15/04/02)

.INPUTS
	None

.OUTPUTS
	None
	
.PARAMETER Action
	Available words are "Add" or "Remove"
	
.PARAMETER Scope
	NETBIOS domain name or WORKGROUP

.PARAMETER Name
	Account name

.PARAMETER Password
	Account password (encoded)

.PARAMETER Description
	Account description

.PARAMETER MemberOf
	Account's Member of

.PARAMETER PwdNeverExpires
	Set if the password never expires

.PARAMETER PwdBlocked
	Set if the password cannot be changed

.EXAMPLE
	./ManageLocalAccount.ps1 -Action Add -Scope "EUR" -Name "SvcAccount" -Password "dG90bw=="

	./ManageLocalAccount.ps1 -Action Add -Scope "EUR" -Name "SvcAccount" -Password "dG90bw==" -MemberOf "Administrators" -PwdNeverExpires

#>
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][ValidateSet("Add","Remove")][String] $Action = "",
	[Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Scope,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Name,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Password = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Description = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $MemberOf = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $PwdNeverExpires,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $PwdBlocked
)

$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################
$PSConfPath = "$PSScriptRoot\conf"
$strModulePath = "$tsenv:LogPath\LocalAccounts"

# Import module Local Accounts
try {
    # MANDATORY to copy module locally otherwise it not works
    Copy-Item "$PSScriptRoot\LocalAccounts" -Destination $strModulePath -Recurse -Force | Out-Null
    Import-Module $strModulePath
}
catch {
    Write-Error "Cannot import LocalAccounts Module! $($_.Exception.Message)"
}


##################################################
##               GLOBAL VARIABLES               ##
##################################################


##################################################
##               Functions and Subs             ##
##################################################


##################################################
##                     MAIN                     ##
##################################################
# Using Get-DomainName from the Universal.Installer module
$strDomain = Get-DomainName -Short
If ($Scope -eq $strDomain) {
    Switch ($Action) {
        "Add" {
            try {
                If ($Password -eq "") {Write-Error "Password not found in the XML File! Exit"}

                $oUser = Get-LocalUser -Name $Name -ErrorAction SilentlyContinue
                If ($oUser -eq $null) {
                    Write-Host "Creating $Name User..."
                    New-LocalUser -Name $Name -Password (Get-DecodeString $Password) -PassThru
                    Write-Host "User created successfully"
                }
                Else {
                    Set-LocalUserPassword -Name $Name -NewPassword (Get-DecodeString $Password)
                }

                Write-Host "Managing $Name User..."
                $AccSettings = @{
                    Name = $Name
                    Description = $Description
                    PasswordNeverExpires = $PwdNeverExpires.ToBool()
                    CannotChangePassword = $PwdBlocked.ToBool()
                }
                Set-LocalUser @AccSettings
                Write-Host "User managed successfully"
            }
            catch {
                Write-Error "Cannot manage $Name User! $($_.Exception.Message)"
            }

            # Add user to group(s)
            try {
                $oUser = Get-LocalUser -Name $Name -ErrorAction SilentlyContinue
                If ($MemberOf -ne "") {
                    $arrMembers = $MemberOf -split ","

                    $arrMembers | % {
                        $strGrpName = $_.Trim()
                        Write-Host "Adding $Name User to $strGrpName Group..."
                        If ((Get-LocalGroup -Name $strGrpName -ErrorAction SilentlyContinue) -ne $null) {
                            $mbr = Get-LocalGroupMember -Name $strGrpName | ? {$_.Name -eq $Name}
                            If ($mbr -eq $null) {
                                Add-LocalGroupMember -Name $strGrpName -Members $oUser
                                Write-Host "User added"
                            }
                            Else {
                                Write-Host "User already exists in the Group. Nothing to do"
                            }
                        }
                        Else {
                            Write-Warning "$strGrpName Group not exists!"
                        }
                    }
                }
            }
            catch [System.DirectoryServices.AccountManagement.PrincipalOperationException] {
                Write-Warning "Cannot add $Name User in $($oGroup.Name) Group because at least one unknown user's SID exists in the group"
                Exit
            }
            catch {
                Write-Error "Cannot add user! $($_.Exception.Message)"
            }
        }
        "Remove" {
            Write-Host "Removing $Name User..."
            try {
                If ((Get-LocalUser -Name $Name -ErrorAction SilentlyContinue) -ne $null) {
                    Remove-LocalUser -Name $Name
                    Write-Host "User removed successfully"
                }
                Else {
                    Write-Host "User does not exists. Nothing to do"
                }
            }
            catch {
                Write-Error "Cannot remove user! $($_.Exception.Message)"
            }
        }
    }
}
Else {
    Write-Host "$Scope not match with $strDomain. Nothing to do"
}
