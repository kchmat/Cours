<#
.SYNOPSIS
	Script used to set Dist Server from Netmap

.DESCRIPTION
	

.LINK
	
.PARAMETER URL
    Set the URL of Netmap web service

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (20/12/2016)
    ChangeLog: Initial version (20/12/2016)
	
.EXAMPLE
	./SetDistServer.ps1 -NetmapURL <URL>

#>
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $NetmapURL
)

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##               GLOBAL VARIABLES               ##
##################################################
# Registry key master signature path
$sMasterRegKey = "HKLM:\SOFTWARE\SGBUILD\parameters"
# Registry key value for Dist Server
$sMasterRegDistServer = "DISTSERVER"
# Netmap Dist server value name
$sNMDistServer = "INFRA_INSTALLWIN_SERVICE1"


##################################################
##               Functions and Subs             ##
##################################################
# Get Netmap Data
Function Get-NetmapData {
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $URL,
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $IP
    )

    Write-Host "[Get-NetmapData] Getting info from Netmap..."

    # If IP is null or empty, try to get the good one
    If ([System.String]::IsNullOrEmpty($IP)) {
        $IP = (Test-Connection $env:COMPUTERNAME -Count 1).IPV4Address.IPAddressToString
        Write-Host "IP found: $IP"
    }

    If (($IP -split "\.").Count -ne 4) {
        Write-Warning "[Get-NetmapData] $IP is not a valid IPv4 Address"
        return
    }
    

    # Contact Netmap Web Service
    try {
        $r = [System.Net.WebRequest]::Create("$URL/netmap.php?ip=$IP")
        $resp = $r.GetResponse()
        $reqstream = $resp.GetResponseStream()
        $sr = New-Object System.IO.StreamReader $reqstream
        $NetmapCon = $sr.ReadToEnd()
    }
    catch {
        Write-Warning "[Get-NetmapData] Cannot request $URL"
        return
    }
  
    If ($NetmapCon -match '^#') {
        Write-Warning "[Get-NetmapData] Error while requesting Netmap Web Service for $IP ip address."
        return
    }

    $rawTable = $NetmapCon.Split("`n", [System.StringSplitOptions]::RemoveEmptyEntries)
    $netmap = @{}
    ForEach ($row in $rawTable) {
        $data = $row.Split("=", [System.StringSplitOptions]::RemoveEmptyEntries)
        $key = $data[0] -replace "\[\d+\]"
        $value = $data[1].TrimStart("'").TrimEnd("'")
        If ($netmap.Keys -contains $key) {
            $netmap[$key] += $value
        }
        Else {
            $netmap.Set_Item($key, @($value))
        }
    }
    $netmap['IP'] = $ip
    
    Write-Host "[Get-NetmapData] Netmap info returned successfully from $URL for IP $IP"
    return $netmap
}



##################################################
##                     MAIN                     ##
##################################################
# Get the dist server from Netmap
$NetmapData = Get-NetmapData -URL $NetmapURL
If ($NetmapData -ne $null) {
    $distserver = "$($NetmapData[$sNMDistServer])"
}
Else {
    Write-Warning "No value returned from NETMAP. Check connection or network declaration"
    exit
}
# Set the dist server (used by MDT Software Catalog)
If (!([String]::IsNullOrEmpty($distserver))) {
    $distserver = $distserver -replace "\\\\", "" #In case of \\xxx is present
    Write-Host "$sMasterRegDistServer value found: $distserver"
    Set-ItemProperty -Path $sMasterRegKey -Name $sMasterRegDistServer -Value $distserver
    Write-Host "$sMasterRegKey\$sMasterRegDistServer was set"
}
Else {
    Write-Warning "$sMasterRegDistServer value not found! Check network configuration in Netmap"
    Write-Host "$sMasterRegKey\$sMasterRegDistServer value remains $((Get-ItemProperty $sMasterRegKey).$sMasterRegDistServer)"
}
