<#
.SYNOPSIS
	Script used to clean GWiM template installation

.DESCRIPTION
	

.LINK


.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (09/01/2017)
    ChangeLog: Initial version (09/01/2017)
	
.EXAMPLE
	./CleanGWiMData.ps1

#>
# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##               GLOBAL VARIABLES               ##
##################################################
# GWiM Deployment log path
$sLogPath = "$env:ProgramFiles\SGBUILD\Logs"
# GWiM summary log path
$sSumLogPath = "$env:SystemDrive\_DeploymentSummary.html"


##################################################
##               Functions and Subs             ##
##################################################


##################################################
##                     MAIN                     ##
##################################################
Remove-Item $sLogPath -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
Remove-Item $sSumLogPath -Recurse -Force -ErrorAction SilentlyContinue | Out-Null