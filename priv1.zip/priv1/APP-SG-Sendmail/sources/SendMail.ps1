# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   4.2 (02/15/17)
# // Developer: Florian Valente
# // 			Pierre BOUSSINGAULT
# // Purpose:   Send a Summary Mail at the end of the deployment
# // Usage:     SendMail.ps1 <args>
# //            Args:
# //            [-Action]: WORKGROUP, DOMAIN or ALL. Specify in which environment the summary mail will be sent
# //            [-SMTPServer]: Force a SMTP Server
# //            [-From]: Force a sender
# //            [-To]: Force recipient(s), separated by ","
# //            [-Cc]: Force recipient(s) in copy, separated by ","
# //            [-Summary]: Create an HTML Summary in C: root
# //
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][ValidateSet("WORKGROUP","DOMAIN","ALL")][String] $Action = "ALL",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $SMTPServer = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $From = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $To = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Cc = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $Summary
)

$ErrorActionPreference = 'Stop'


Function Parse-BDDLog {
    PARAM (
        [String]$Path
    )
    
    $Exceptions = @("The network path was not found", "Application returned the error code", "Message containing password has been suppressed", "'Microsoft.PowerShell.Management' snap-in was already imported")

    If (Test-Path $Path) {
        $file = Get-Content $Path

        $bException = $false
        $bFirst = $false
        $Global:sBuffer += "<table>"

        $file | Where-Object {
            $bProcess = $false
            $sLine = $_.ToString()
            

            If ($sLine.Contains('<![LOG[')) { #Line beginning found
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage = $sLine.Substring(7)
                }
                Else {
                    $sMessage = $sLine.Substring(7, $sLine.IndexOf(']LOG]!>')-7)
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }
            Else { #No line beginning found, continuation
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage += "<br /> $sLine"
                }
                Else {
                    $sMessage += "<br /> $($sLine.Substring(0, $sLine.IndexOf(']LOG]!>')))"
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }

            # Inspect the type
            If ($bProcess) {
                # Check if message content contains Exceptions
                ForEach ($e in $Exceptions) {
                    If ($sMessage.Contains($e)) {
                        $bException = $true
                        Break
                    }
                }

                If (!($bException)) {
                    # Add the message to the details display
                    If ($sType -eq "2") {
                        $Global:intWarning += 1
                        $Global:sBuffer += "<tr><td>WARNING</td>"
                        $Global:sBuffer += "<td>$sMessage</td></tr>"
                    }
                    ElseIf ($sType -eq "3") {
                        If (!($bException)) {
                            $Global:intError += 1
                            $Global:sBuffer += "<tr><td>ERROR</td>"
                            $Global:sBuffer += "<td>$sMessage</td></tr>"
                        }
                    }
                }
                Else {
                    $bException = $false
                }
            }
        }
        $Global:sBuffer += "</table>"
        Write-Host "$($Global:intError) errors and $($Global:intWarning) warnings found on BDD.log"
    }
    Else {
        Write-Host "No log to parse"
    }
}


Function Zip-File {
    PARAM (
        [String]$Path,
        [String]$File
    )

    If (Test-Path $Path) {
        If (!(Test-Path $File)) {
        	Set-Content $File ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))
	        (dir $File).IsReadOnly = $false
        }
        Else {
            Remove-Item $File -Force | Out-Null
        }

        $shellApplication = New-Object -ComObject Shell.Application
        $zipPackage = $shellApplication.NameSpace($File)

        $zipPackage.CopyHere($Path)
        Start-Sleep -Milliseconds 500
        Write-Host "Log file zipped successfully"
    }
}


<#
# V1 based on the computer's date
# Issues with Worldwide deployment and jetlag or server's time misconfiguration
Function Get-InstallDuration {
    # Get Install Date
    $installDate = ([WMI]'').ConvertToDateTime((Get-WmiObject Win32_OperatingSystem).InstallDate)
    
    # Get Current Date
    $currentDate = Get-Date

    # Get Install Duration
    $duration = $currentDate - $installDate

    $result = ""
    If ($duration.Days -ne 0) {
        $result += "$($duration.Days) Days "
    }
    $result += "$($duration.Hours)h $($duration.Minutes)min $($duration.Seconds)sec"

    return $result
}
#>

# V2 based on the data retrieved from MDT Monitoring
Function Get-InstallDuration {
    $result = ""
    
    # Connect to the MDT Monitoring Web Service located on the Primary Server
    $strMDTMonURI = ($tsenv:EventService) -replace "9800", "9801"
    $oWS = New-Object System.Net.WebClient

    # Get the result in a XML variable
    try {
        [xml]$xml = $oWS.DownloadString("$strMDTMonURI/MDTMonitorData/Computers")

        $xml.feed.entry.content.properties | % {
            # Get properties for the computer on deployment
            If ($_.Name -eq $tsenv:OSDComputerName) {
                $startTime = Get-Date $_.StartTime.'#text' #Get deployment start time
                $endTime = Get-Date $_.LastTime.'#text' #Get deployment last time (end time value not set yet because the deployment isn't finished)
                $duration = $endTime - $startTime #Get deployment duration
                If ($duration.Days -ne 0) {
                    $result += "$($duration.Days) Days "
                }
                $result += "$($duration.Hours)h $($duration.Minutes)min $($duration.Seconds)sec"
            }
        }
    }
    catch {
        $result = "Data unavailable"
    }

    return $result
}


Function Validate-Email {
    PARAM (
        [String]$Address
    )

    ($Address -as [System.Net.Mail.MailAddress]).Address `
        -eq $Address -and $Address -ne $null
}


Function Test-Addresses {
    PARAM (
        [String]$Addresses
    )

    If ($Addresses -ne "") {
        Write-Host "Testing address list: $Addresses..."
        $tab = $Addresses -split ","
        ForEach ($address in $tab) {
            If (!(Validate-Email -Address $address)) {
                Write-Error "ERROR: $address is invalid! Exit"
            }
            Else {
                Write-Host "OK: $address"
            }
        }
    }
    Else {
        Write-Host "No addresses found"
        return $false
    }

    return $true
}


Function New-HTMLSummary {
    # Create header of the HTML file
    $header = "<style>"
    $header += "BODY{background-color:WhiteSmoke;}"
    $header += "TABLE{border-width:1px; border-style:solid; border-color:black; border-collapse:collapse;}"
    $header += "TH{border-width:1px; padding:5px; border-style:solid; border-color:black; background-color:SteelBlue;}"
    $header += "TD{border-width:1px; padding:5px; border-style:solid; border-color:black; background-color:LightCyan;}"
    $header += "</style>"

    # Create body of the HTML file
    $body = "<H2><u><center>$env:COMPUTERNAME</center></u></H2>"
    #$body += "<font size='4' color='#FF6600'>This message is sent automatically and the identity of the sender can not be technically verified.</font><br /><br />"
    $body += "<b>Deployment status:</b><br />"
    $body += "<font color='"
    If ($intError -gt 0) {$body += "red"}
    ElseIf ($intWarning -gt 0) {$body += "#FF6600"} #font color Orange
    $body += "'> - Errors: $intError<br />"
    $body += " - Warnings: $intWarning</font><br /><br />"
    $body += "<b>Error details:</b><br />"
    $body += $sBuffer
    $body += "<br /><b>Information:</b>"

    # Initialize deployment collection
    $tRegHash = @{}
    $tRegHash.Add("Installer", "$tsenv:SGInstaller")
    $tRegHash.Add("Master Version", "$tsenv:SGMasterVersion")
    $tRegHash.Add("Comment", "$tsenv:SGDescription")
    If ($tsenv:IsUEFI -eq "True") { $strBootMode = "UEFI" }
    Else { $strBootMode = "Legacy BIOS" }
    $tRegHash.Add("Boot Mode", $strBootMode)
    $tRegHash.Add("Install Duration", (Get-InstallDuration))
    $osInfo = Get-WmiObject -Class Win32_OperatingSystem
    $tRegHash.Add("OS Name", "$($osInfo.Caption) SP$($osInfo.ServicePackMajorVersion)")
    $tRegHash.Add("Department", "$tsenv:SGDept")
    $tRegHash.Add("Server Role", "$tsenv:SGRole")
    $tRegHash.Add("Environment", "$tsenv:SGEnvironment")
    If ($tsenv:SGCountry -ne "") {$tRegHash.Add("Country", "$tsenv:SGCountry")}
    If ($tsenv:SGRILOName -ne "") {$tRegHash.Add("Net RILO Name", "$tsenv:SGRILOName")}
    $tRegHash.Add("Hardening", "$tsenv:SGGPOPackName")
    $tRegHash.Add("Model", "$tsenv:Make $tsenv:Model")
    $tRegHash.Add("Net Gateway", "$tsenv:OSDAdapter0Gateways")
    $tRegHash.Add("Net IP Address", "$tsenv:OSDAdapter0IPAddressList")
    # Get Mac Address. Cannot use $tsenv:OSDAdapter0MacAddress in case of static IP was defined in BDD Welcome.
    # If server has several net cards, it may appears <DHCP> if the selected net card was not the OSDAdapter0.
    $NetMac = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True" | Where-Object {$_.IPAddress[0] -eq "$tsenv:OSDAdapter0IPAddressList"}).MacAddress
    $tRegHash.Add("Net MAC Address", "$NetMac")
    $tRegHash.Add("Barcode", "$tsenv:SGBarcode")
    If (Ping-Machine -Name "marleyweb.fr.world.socgen") {
        $tRegHash.Add("Marley", "https://marleyweb.fr.world.socgen/bob/link.php?HOST=$env:COMPUTERNAME")
    }
    If ($tsenv:JoinWorkgroup -ne "") {$tRegHash.Add("Domain", "$tsenv:JoinWorkgroup")}
    ElseIf ($tsenv:JoinDomain -ne "") {
        $tRegHash.Add("Domain", "$tsenv:JoinDomain")
        # Get OU in Dot style (not LDAP style)
        If (!([System.String]::IsNullOrEmpty($tsenv:MachineObjectOU))) {
            $aOU = $tsenv:MachineObjectOU -split "," | ? {$_ -match "OU="} | % {$_ -replace "OU=", ''}
            [array]::Reverse($aOU)
            $tRegHash.Add("Domain OU", "$($aOU -join "\")")
        }
    }
    # Get Partitions information
    $PartCpt = 1
    Get-WmiObject Win32_Volume -Filter "DriveType=3" | % {
        $tRegHash.Add("Partition $PartCpt", "$($_.DriveLetter) $($_.Label) - $([System.Math]::Truncate($_.Capacity/1GB)+1)GB")
        $PartCpt++
    }

    # Create PS Object including hash table
    $colInfo = @()
    $tRegHash.GetEnumerator() | Sort-Object Name | % {
        $data = New-Object -TypeName PSObject
        $data | Add-Member -NotePropertyName Name -NotePropertyValue "$($_.Key)"
        $data | Add-Member -NotePropertyName Value -NotePropertyValue "$($_.Value)"
        # Add info to the collection
        $colInfo += $data
    }

    Write-Host "HTML Summary created successfully"

    # Convert apps collection to HTML data and set content into the output stream
    return ($colInfo | ConvertTo-Html Name, Value -Head $header -Body $body)
}


Function Send-Mail {
    PARAM (
        [String]$Attachment
    )

    Write-Host "Sending mail..."

    try {
        $Args = @{
            SmtpServer = "$SMTPServer"
            From = $From
            To = $To -split ","
            Subject = "$strSubject"
            Body = "$strBody"
        }
        # Add Cc if there is
        If ($Cc -ne "") {
            $Args += @{Cc = $Cc -split ","}
        }
        # Add attachment if found
        If (Test-Path $Attachment) {
            $Args += @{Attachments = $Attachment}
        }

        Send-MailMessage @Args -BodyAsHtml
        Write-Host "Mail sent successfully"
    }
    catch {
        Write-Warning "WARNING: Send mail failed! $($_.Exception.Message)"
    }
}


########
# MAIN #
########
If (($tsenv:SkipSendMail -eq "YES") -and (!($Summary))) {
    Write-Host "SkipSendMail=YES. Nothing to do"
    Exit
}

# Test if the server is joined to a domain (function is in Universal.Installer)
$IsInDomain = Test-JoinDomain

# The Summary Mail is only sent if the server is in Workgroup
If (($Action -eq "WORKGROUP") -and ($IsInDomain)) {
    Write-Host "Server is joined to $tsenv:JoinDomain Domain and WORKGROUP switch was detected. Exit"
    Exit
}
# The Summary Mail is only sent if the server is in Domain
ElseIf (($Action -eq "DOMAIN") -and ($IsInDomain -eq $false)) {
    Write-Host "Server is in the $tsenv:JoinWorkgroup Workgroup and DOMAIN switch was detected. Exit"
    Exit
}

# Parse BDD.log to get Errors and Warnings
$Global:intError = 0
$Global:intWarning = 0
$Global:sBuffer = ""
$strLogPath = "$tsenv:LogPath\BDD.log"
If (Test-Path $strLogPath) {
    # Parse the log to get number of Errors and Warnings
    Parse-BDDLog -Path $strLogPath
    
    # Zip the log file
    $strZipPath = "$tsenv:LogPath\log.zip"
    Zip-File -Path $strLogPath -File $strZipPath
}
Else {
    $strZipPath = "fakezip"
}

# Create the HTML Summary
$Global:strBody = New-HTMLSummary
# Save the HTML Summary into a file
If ($Summary) {
    $strSummaryPath = "$env:SystemDrive\_DeploymentSummary.html"
    $Global:strBody | Out-File $strSummaryPath
    Write-Host "Deployment Summary saved in $strSummaryPath"
}

# Initialize Send Mail in case of SkipSendMail = NO
If ($tsenv:SkipSendMail -eq "NO") {
    # Check if a SMTP server was specified
    If ($SMTPServer -eq "") {$SMTPServer = $tsenv:SGSMTPServer}
    # Ping-Machine function is included to the Wrapper
    If (!(Ping-Machine -Name $SMTPServer)) {
        Write-Host "SMTP Server $SMTPServer unresponsive! Exit"
        Exit
    }
    Else {
        Write-Host "SMTP Server used: $SMTPServer"
    }

    # Check mail addresses (From, To, Cc)
    Write-Host "Checking From address..."
    If ($From -eq "") {$From = "$tsenv:SGMailFrom"}
    Test-Addresses -Addresses $From

    Write-Host "Checking To addresses..."
    If ($To -eq "") {$To = "$tsenv:SGMailTo"}
    $To = $To -replace ";", "," -replace " ", ""
    Test-Addresses -Addresses $To

    Write-Host "Checking Cc addresses..."
    If ($Cc -eq "") {$Cc = "$tsenv:SGMailCc"}
    $Cc = $Cc -replace ";", "," -replace " ", ""
    Test-Addresses -Addresses $Cc

    # Set the mail subject
    $Global:strSubject = "[MASTER][E:$($Global:intError)] $env:COMPUTERNAME master installation is finished"

    # Wait 2 seconds until the writing of the log
    Start-Sleep 2

    # Send Mail
    Send-Mail -Attachment $strZipPath
}
Else {
    Write-Host "SkipSendMail=YES. Nothing to do"
}
