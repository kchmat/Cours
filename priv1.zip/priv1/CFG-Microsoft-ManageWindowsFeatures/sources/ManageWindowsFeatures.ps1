<#
.SYNOPSIS
	This script allows to add or remove Windows Roles and Features

.DESCRIPTION
	To use it, set Name of feature(s) needed.
    To have a list of all feature names available, run this command in a PS prompt:
    Get-WindowsFeature | Where-Object {!$_.Installed} | Select-Object -Property Name,DisplayName

.LINK
    https://technet.microsoft.com/en-us/library/jj205465(v=wps.630).aspx

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (15/07/06)
    ChangeLog: 1.0 (15/07/06)

.INPUTS
	File: (optional) XML file containing Server Roles/Features configuration
          Exported from the Server Manager wizard

.OUTPUTS
	
	
.PARAMETER Name
	Name of the feature(s), separated by ,
    Not mandatory if ConfigurationFile parameter is used
	
.PARAMETER ConfigurationFile
	XML file containing Server Roles/Features configuration exported from the Server Manager wizard

.PARAMETER UseSources
	Switch to specify that sources are used

.PARAMETER IncludeAllSubFeature
	Switch to specify that all subordinate role services, and all subfeatures of parent roles, role services,
    or features specified by the Name parameter should be installed.

.PARAMETER IncludeManagementTools
    Switch to specify that all applicable management tools of the roles, role services,
    or features specified by the Name parameter should be installed.

.PARAMETER Remove
	Switch to indicate that feature(s) will be removed

.PARAMETER Force
	Switch to force uninstallation of selected feature(s)
    

.EXAMPLE
	./ManageWindowsFeature.ps1 -Name "web-*"

	./ManageWindowsFeature.ps1 -ConfigurationFile "InstallDC.xml"

    ./ManageWindowsFeature.ps1 -Name "WFF" -Remove -Force

#>
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $Name = "",
	[Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $ConfigurationFile = "",
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $UseSources,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $IncludeAllSubFeature,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $IncludeManagementTools,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $Remove,
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][Switch] $Force
)

$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################
# Get Conf folder
$PSConfPath = "$PSScriptRoot\conf"


##################################################
##               GLOBAL VARIABLES               ##
##################################################
$Source = "$PSScriptRoot\bin\$(Get-OSVersion)"
$SourceFlagName = "_sources.flag"
$SourceLocalPath = [System.IO.Path]::GetPathRoot($tsenv:LogPath) + "MININT\sources\$tsenv:Architecture"


##################################################
##               Functions and Subs             ##
##################################################
Function Copy-SourcesLocally {
    PARAM (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Path
    )

    # Remove all local existing Windows sources if exists
    Remove-Item -Path $SourceLocalPath -Recurse -Force -ErrorAction SilentlyContinue | Out-Null

    # Use Start-Copy of Universal.Installer Module
    Start-Copy -Source $Path -Destination $SourceLocalPath -Exclude $SourceFlagName
}


Function Get-WIMPath {
    If (!([String]::IsNullOrEmpty($tsenv:InstallFromPath))) {
        # InstallFromPath variable is set during a master deployment
        $strWIMPath = $tsenv:InstallFromPath
        $strWIMIndex = $tsenv:ImageIndex
    }
    Else {
        $strTSID = "$tsenv:SGDept-$tsenv:SGOSCode-PRD"

        # Load the TS.XML and get the OSGUID
        $xmlTS = [xml](Get-Content "$tsenv:DeployRoot\Control\$strTSID\ts.xml" -ErrorAction SilentlyContinue)
        If ($xmlTS -eq $null) {
            Write-Host "Task Sequence ID $strTSID not found! Cannot find WIM path"
            return
        }
        $objOS = $xmlTS.SelectSingleNode("//globalVarList/variable[@name='OSGUID']")
        If ($objOS -eq $null) {
            Write-Host "OS GUID not found! Cannot find WIM path"
            return
        }
        $strOSGUID = $objOS.'#text'
        
		# Get the OS record
        $xmlOS = [xml](Get-Content "$tsenv:DeployRoot\Control\OperatingSystems.xml")
        $objOS = $xmlOS.SelectSingleNode("//os[@guid='$strOSGUID']")
        If ($objOS -eq $null) {
            Write-Host "OS info not found! Cannot find WIM path"
            return
        }

		# Get OS properties
        $strWIMPath = $objOS.ImageFile
        $strWIMIndex = $objOS.ImageIndex

        # Replace the . by the DeployRoot path
        If ($strWIMPath.Substring(0,1) -eq ".") {
            $strWIMPath = $tsenv:DeployRoot + $strWIMPath.Substring(1)
            If (!(Test-Path $strWIMPath)) {
                Write-Host "WIM file $strWIMPath not found!"
                return
            }
        }
    }

    Write-Host "WIM Path $strWIMPath"
    Copy-SourcesLocally -Path $strWIMPath
    $strWIMPath = "$SourceLocalPath\$(Split-Path $strWIMPath -Leaf)"
    
    Write-Host "WIM Source found: $strWIMPath"
    Write-Host "WIM Index found: $strWIMIndex"

    return "wim:\$($strWIMPath):$($strWIMIndex)" -replace "\\", "/"
}


Function Get-OSSource {
	$strSourcePath = ""
    $strWindowsSources = ""

	# If the user explicitly set WindowsSource, copy the files locally, 
	# pass the value along via the source switch, and limit access to
	# the internet.

	If (!([String]::IsNullOrEmpty($tsenv:WindowsSource))) {
        Write-Host "Windows Source = $tsenv:WindowsSource"
        If (Test-Path $tsenv:WindowsSource) { $strWindowsSources = $tsenv:WindowsSource }
    }
    ElseIf (!([String]::IsNullOrEmpty($tsenv:SourcePath))) {
        Write-Host "Source Path = $tsenv:SourcePath"
        If (Test-Path $tsenv:SourcePath) { $strWindowsSources = $tsenv:SourcePath }
    }
    Else {
        # Trying to get WIM file
        $strSourcePath = Get-WIMPath
    }

    If ($strWindowsSources -ne "") {
        $strSourcePath = "$strWindowsSources\sources\sxs"
	    If (Test-Path $strSourcePath) {
            Copy-SourcesLocally -Path $strSourcePath
            $strSourcePath = $SourceLocalPath
        }
	    Else {
		    Write-Host "SourcePath was set, but $strSourcePath does not exist, not using local source."
	    }
    }

    return $strSourcePath
}


Function Install-WindowsServerFeatures {
    Write-Host "Installing Windows Server Features..."

    # Split feature names
    If ($Name -ne "") {
        $arrFeaturesName = $Name -split ","
    }

    # Add Source Path for Windows Server 2012 R2 and above
    If ($UseSources -and ((Get-OSVersion) -ge 6.3)) {
        If (Test-Path "$Source\$SourceFlagName") {
            Copy-SourcesLocally -Path $Source
            $strSource = $SourceLocalPath
        }
        Else {
            $strSource = Get-OSSource
        }
        If ($strSource -ne "") {
            $cmdletArgs = @{
                Source = $strSource
            }
            Write-Host "Windows sources used: $strSource"
        }
    }

    $intRestartResult = 0
    If (($arrFeaturesName.Count -ne 0) -and ($ConfigurationFile -eq "")) {
        # Include Sub Feature
        $cmdletArgs += @{
            IncludeAllSubFeature = $IncludeAllSubFeature
        }
        # Include Management Tools for Windows Server 2012 R2 and above
        If ((Get-OSVersion) -ge 6.3) {
            $cmdletArgs += @{
                IncludeManagementTools = $IncludeManagementTools
            }
        }
        Else {
            Write-Host "IncludeManagementTools parameter is only available on Windows Server 2012 R2 and above"
        }

        $arrFeaturesName | % {
            $objFeature = Get-WindowsFeature -Name $_
            If ($objFeature -eq $null) {
                Write-Warning "Feature $_ not exists"
            }
            ElseIf ($objFeature.Installed -eq $true) {
                Write-Host "Feature $($objFeature.Name) already installed. Nothing to do"
            }
            Else {
                # A loop to be able to manage feature name like "web-*"
                $objFeature | % {
                    $strFeatureName = $_.Name
                    Write-Host "Installing Windows Role/Feature $strFeatureName..."
                    $result = Add-WindowsFeature -Name $strFeatureName @cmdletArgs -WarningAction SilentlyContinue
                    If ($result.Success -eq $false) {
                        If ($result.RestartNeeded -eq "Yes") {
                            Write-Error "Failed to process Windows feature, reboot required."
                        }
                        Else {
                            Write-Error "Failed to process Windows feature."
                        }
                    }
                    If ($result.RestartNeeded -eq "Yes") {
                        $intRestartResult = 1
                        Write-Host "Windows feature processed, reboot required."
                    }
                    Else {
                        Write-Host "Windows feature processed"
                    }
                }
            }
        }
    }
    ElseIf ($ConfigurationFile -ne "") {
        If ((Get-OSVersion) -lt 6.3) {
            Write-Host "ConfigurationFile parameter is only available on Windows Server 2012 R2 and above! Exit"
            return
        }

        $ConfigurationFilePath = "$PSScriptRoot\$ConfigurationFile"
        If (!(Test-Path $ConfigurationFilePath)) {
            Write-Error "Configuration File $ConfigurationFilePath was not found! Exit"
        }
        Else {
            $cmdletArgs = @{
                ConfigurationFilePath = "$ConfigurationFilePath"
            }
        }

        Write-Host "Installing Windows Roles/Features by using a Configuration File..."
        Write-Host "Configuration File used: $ConfigurationFilePath"
        $result = Add-WindowsFeature @cmdletArgs -WarningAction SilentlyContinue
        If ($result.Success -eq $false) {
            If ($result.RestartNeeded -eq "Yes") {
                Write-Error "Failed to process Windows feature, reboot required."
            }
            Else {
                Write-Error "Failed to process Windows feature."
            }
        }
        If ($result.RestartNeeded -eq "Yes") {
            $intRestartResult = 1
            Write-Host "Windows feature processed, reboot required."
        }
        Else {
            Write-Host "Windows feature processed"
        }
    }

    return $intRestartResult
}


Function Uninstall-WindowsServerFeatures {
    Write-Host "Uninstalling Windows Server Features..."

    # Split feature names
    If ($Name -ne "") {
        $arrFeaturesName = $Name -split ","
    }

    $intRestartResult = 0
    # Remove Windows Features
    If ($arrFeaturesName.Count -ne 0) {
        # A loop to be able to manage feature name like "web-*"
        $arrFeaturesName | % {
            $objFeature = Get-WindowsFeature -Name $_
            If ($objFeature -eq $null) {
                Write-Warning "Feature $_ not exists"
            }
            ElseIf ($objFeature.Installed -eq $false) {
                Write-Host "Feature $($objFeature.Name) not installed. Nothing to do"
            }
            Else {
                $objFeature | % {
                    $strFeatureName = $_.Name
                    If ($Force -and ((Get-OSVersion) -ge 6.3)) {
		                Write-Host "Completely removing Windows Role/Feature $strFeatureName..."
		                $result = Remove-WindowsFeature -Name $strFeatureName -Remove -WarningAction SilentlyContinue
	                }
	                Else {
		                Write-Host "Uninstalling Windows Role/Feature $strFeatureName"
		                $result = Remove-WindowsFeature -Name $strFeatureName -WarningAction SilentlyContinue
	                }

                    If ($result.Success -eq $false) {
                        If ($result.RestartNeeded -eq "Yes") {
                            Write-Error "Failed to process Windows feature, reboot required."
                        }
                        Else {
                            Write-Error "Failed to process Windows feature."
                        }
                    }
                    If ($result.RestartNeeded -eq "Yes") {
                        $intRestartResult = 1
                        Write-Host "Windows feature processed, reboot required."
                    }
                    Else {
                        Write-Host "Windows feature processed"
                    }
                }
            }
        }
    }

    return $intRestartResult
}


##################################################
##                     MAIN                     ##
##################################################
If (($ConfigurationFile -eq "") -and ($Name -eq "")) {
    Write-Error "Name or ConfigurationFile parameter must be present!"
}



# Install Windows Feature
If (!$Remove) {
    $Result = Install-WindowsServerFeatures
}
Else {
    $Result = Uninstall-WindowsServerFeatures
}

If ($Result -gt 0) {
    Write-Warning "Windows Features correctly managed but a reboot is required!"
}
