﻿#region STEP1: Author MOF (Declarative)
Configuration InstallIIS {
    # Import DSC IIS resource
    Import-DscResource -ModuleName xWebAdministration #Must be copied locally through the _config.xml file

    $sDefaultWebSitePath = "D:\wwwroot\DefaultWebSite"
    
    Node "localhost" {
        # Install the IIS Role
        foreach ($Feature in @("Web-Server","Web-Windows-Auth","Web-Mgmt-Console")) {
            WindowsFeature $Feature {
                Ensure = "Present"
                Name = $Feature
            }
        }

        # Move the default website content
        File DefaultPath {
            SourcePath = "C:\inetpub\wwwroot"
            DestinationPath = $sDefaultWebSitePath
            Type = "Directory"
            Ensure = "Present"
            Recurse = $true
            Force = $true
            DependsOn = "[WindowsFeature]Web-Server"
        }

        # Set the path of the default web site and stop it
        xWebsite DefaultSite { 
            Ensure = "Present" 
            Name = "Default Web Site" 
            State = "Stopped" 
            PhysicalPath = $sDefaultWebSitePath
            DependsOn = "[File]DefaultPath"
        }

        # Remove the old default web site content
        File RemoveDefaultPath {
            DestinationPath = "C:\inetpub\wwwroot"
            Type = "Directory"
            Ensure = "Absent"
            Recurse = $true
            Force = $true
            DependsOn = "[xWebsite]DefaultSite"
        }
    }
}
#endregion STEP1


#region STEP2: Generate MOF
$oDSC = InstallIIS -OutputPath "$tsenv:LogPath\InstallIIS"
#endregion STEP2


#region STEP3: Push out configuration
Start-DscConfiguration -Path $oDSC.DirectoryName -Verbose -Wait -Force
#endregion STEP3
