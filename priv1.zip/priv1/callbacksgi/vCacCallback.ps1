<#
.SYNOPSIS
	Script used to report to VMware VCAC the deployment status

.DESCRIPTION
	

.LINK
	

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Baptiste HEBERT / Florian VALENTE
	Version: 3.0 (29/11/2017)
    ChangeLog: Initial version (19/12/2014)
        2.0 : Improve vCac Callback Management
        3.0 : Change Callback method (add Write-VMProperties, remove Send-VCACFeedback)
	
.EXAMPLE
	./vCacCallback.ps1

#>

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################



##################################################
##               GLOBAL VARIABLES               ##
##################################################
$VMToolsPath = "${Env:ProgramFiles}\VMware\VMware Tools\vmtoolsd.exe"
$Global:CloudFilePath = "${Env:SystemRoot}\Cloud.env"
$Global:intError = 0
$Global:intWarning = 0

##################################################
##               Functions and Subs             ##
##################################################
Function Write-VMProperties {
	PARAM (
		[String]$Status,
		[String]$Message,
		[String]$Detail
	)

	$objParams = @{
        FilePath = $VMToolsPath
        RedirectStandardOutput = $CloudFilePath
    }
    $strCmd = "--cmd ""info-set guestinfo.postinstall.{0} {1}"""

    # Update VM property: Status
    Start-Process @objParams -ArgumentList ($strCmd -f "status", $Status) -PassThru -Wait

    # Update VM property: Message
    Start-Process @objParams -ArgumentList ($strCmd -f "message", $Message) -PassThru -Wait

    # Update VM property: Detail
    Start-Process @objParams -ArgumentList ($strCmd -f "detail", $Detail) -PassThru -Wait
}



Function Parse-BDDLog {
    PARAM (
        [String]$Path
    )
    
    $Exceptions = @("The network path was not found", "Application returned the error code", "Message containing password has been suppressed", "'Microsoft.PowerShell.Management' snap-in was already imported")

    If (Test-Path $Path) {
        $file = Get-Content $Path

        $bException = $false
        $bFirst = $false

        $file | Where-Object {
            $bProcess = $false
            $sLine = $_.ToString()
            

            If ($sLine.Contains('<![LOG[')) { #Line beginning found
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage = $sLine.Substring(7)
                }
                Else {
                    $sMessage = $sLine.Substring(7, $sLine.IndexOf(']LOG]!>')-7)
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }
            Else { #No line beginning found, continuation
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage += "<br /> $sLine"
                }
                Else {
                    $sMessage += "<br /> $($sLine.Substring(0, $sLine.IndexOf(']LOG]!>')))"
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }

            # Inspect the type
            If ($bProcess) {
                # Check if message content contains Exceptions
                ForEach ($e in $Exceptions) {
                    If ($sMessage.Contains($e)) {
                        $bException = $true
                        Break
                    }
                }

                If (!($bException)) {
                    # Add the message to the details display
                    If ($sType -eq "2") {
                        $Global:intWarning += 1
                    }
                    ElseIf ($sType -eq "3") {
                        If (!($bException)) {
                            $Global:intError += 1
                        }
                    }
                }
                Else {
                    $bException = $false
                }
            }
        }
        Write-Host "$($Global:intError) errors and $($Global:intWarning) warnings found on BDD.log"

        If ($Global:intError -gt 0) {
            return 1
        }
        ElseIf ($Global:intWarning -gt 0) {
            return 2
        }
        Else {
            return 0
        }
    }
    Else {
        Write-Host "No log to parse"
    }
}




##################################################
##                     MAIN                     ##
##################################################

$hostname = $env:COMPUTERNAME
$sDistributionServer = $($tsenv:DeployRoot).Split("\")[2]
$sRemoteLogPath = "\\$sDistributionServer\MasterLogs$"
$strLogPath = "$tsenv:LogPath\BDD.log"


If (Test-Path $strLogPath) {
    # Parse the log to get number of Errors and Warnings
    $result = Parse-BDDLog -Path $strLogPath
	
    # Build the vCac Message
    $sMsg = "[$($hostname)] {0} - $($Global:intError) errors, $($Global:intWarning) warnings"

    Switch ($result) {
        0 { 
			$vcacStatus = "OK"; $vcacMessage = ($sMsg -f "GOOD")
		}
        1 {
			$vcacStatus = "KO"; $vcacMessage = ($sMsg -f "FAIL")
		}
        2 {
			$vcacStatus = "WARN"; $vcacMessage = ($sMsg -f "WARN")
		}
    }

    try {
		# Try to write OVFENV for callback
		Write-VMProperties -Status $vcacStatus -Message $vcacMessage -Detail $vcacMessage
		Write-Host "ovfenv properties write successfully"
	}
    catch {
        Write-Host "ERROR: Cannot write ovfenv properties for feedback! $($_.Exception.Message)" # Used to see what happened in the remote log in case of failure
        Write-Error $_.Exception.Message
    }
    finally {
        If (Test-Path $sRemoteLogPath) {
            # Copy log file to a remote folder to centralize logs
            try {
		        Copy-Item $strLogPath "$sRemoteLogPath\$($hostname)_BDD.log" -Force
	        }
	        catch {
		        Write-Host "Unable to copy BDD.log! $($_.Exception.Message)"
	        }
        }
        Else {
            Write-Warning "$sRemoteLogPath was not found. Check if it exists and is reachable"
        }
    }
}
Else {
    Write-Error "$strLogPath not found! Cannot send VCAC Status"
}