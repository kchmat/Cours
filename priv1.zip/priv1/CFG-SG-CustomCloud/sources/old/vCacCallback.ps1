<#
.SYNOPSIS
	Script used to report to VMware VCAC the deployment status

.DESCRIPTION
	

.LINK
	

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Baptiste HEBERT / Florian VALENTE
	Version: 2.0 (23/03/2017)
    ChangeLog: Initial version (19/12/2014)
        2.0 : Improve vCac Callback Management
	
.EXAMPLE
	./vCacCallback.ps1

#>

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################



##################################################
##               GLOBAL VARIABLES               ##
##################################################
$Global:CloudFilePath = "${Env:SystemRoot}\Cloud.env"
$Global:intError = 0
$Global:intWarning = 0

##################################################
##               Functions and Subs             ##
##################################################
Function Get-VMProperties {
    $Args = @{
        FilePath = "${Env:ProgramFiles}\VMware\VMware Tools\vmtoolsd.exe"
        ArgumentList = "--cmd ""info-get guestinfo.ovfenv"""
        RedirectStandardOutput = $CloudFilePath
    }
    Start-Process @Args -PassThru -Wait
    
    $xml = [xml](Get-Content $CloudFilePath)

    Remove-Item $CloudFilePath -Force | Out-Null

    return $xml.Environment.PropertySection.Property
}



Function Parse-BDDLog {
    PARAM (
        [String]$Path
    )
    
    $Exceptions = @("The network path was not found", "Application returned the error code", "Message containing password has been suppressed", "'Microsoft.PowerShell.Management' snap-in was already imported")

    If (Test-Path $Path) {
        $file = Get-Content $Path

        $bException = $false
        $bFirst = $false

        $file | Where-Object {
            $bProcess = $false
            $sLine = $_.ToString()
            

            If ($sLine.Contains('<![LOG[')) { #Line beginning found
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage = $sLine.Substring(7)
                }
                Else {
                    $sMessage = $sLine.Substring(7, $sLine.IndexOf(']LOG]!>')-7)
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }
            Else { #No line beginning found, continuation
                If (!($sLine.Contains(']LOG]!>'))) { #No end label found, start of multiline message
                    $sMessage += "<br /> $sLine"
                }
                Else {
                    $sMessage += "<br /> $($sLine.Substring(0, $sLine.IndexOf(']LOG]!>')))"
                    $sDetails = $sLine.Substring($sLine.IndexOf(']LOG]!>')+7)
                    $sType = $sDetails.Substring($sDetails.IndexOf('type="')+6, 1)
                    $bProcess = $true
                }
            }

            # Inspect the type
            If ($bProcess) {
                # Check if message content contains Exceptions
                ForEach ($e in $Exceptions) {
                    If ($sMessage.Contains($e)) {
                        $bException = $true
                        Break
                    }
                }

                If (!($bException)) {
                    # Add the message to the details display
                    If ($sType -eq "2") {
                        $Global:intWarning += 1
                    }
                    ElseIf ($sType -eq "3") {
                        If (!($bException)) {
                            $Global:intError += 1
                        }
                    }
                }
                Else {
                    $bException = $false
                }
            }
        }
        Write-Host "$($Global:intError) errors and $($Global:intWarning) warnings found on BDD.log"

        If ($Global:intError -gt 0) {
            return 1
        }
        ElseIf ($Global:intWarning -gt 0) {
            return 2
        }
        Else {
            return 0
        }
    }
    Else {
        Write-Host "No log to parse"
    }
}

Function Send-VCACFeedback {
	Param(
		[String]$Url,
        [String]$WFId,
		[String]$VMId,
		[String]$Status,
		[String]$Message,
        [String]$User,
        [String]$Password
	)
    
	$RequestUrl = "$($Url)$($WFId)/executions"
	$Request = "<execution-context xmlns=""http://www.vmware.com/vco""><parameters><parameter name=""virtualMachineId"" type=""string""><string>$($VMId)</string></parameter><parameter name=""status"" type=""string""><string>$($Status)</string></parameter><parameter name=""message"" type=""string""><string>$($Message)</string></parameter></parameters></execution-context>"

    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
    Add-Type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    
    public class IDontCarePolicy : ICertificatePolicy {
        public IDontCarePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate cert,
            WebRequest wRequest, int certProb) {
            return true;
        }
    }
"@
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object IDontCarePolicy

    try {
        $SecPassword = ConvertTo-SecureString $Password -AsPlainText -Force
        $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $User,$Password)))
        $Headers = @{"Authorization"="Basic $($base64AuthInfo)"}
        $Cred = New-Object Management.Automation.PSCredential ($User, $SecPassword)
	    Invoke-RestMethod -Credential $Cred -Uri $RequestUrl -Headers $Headers -ContentType "application/xml" -Method Post -Body $Request -DisableKeepAlive -TimeoutSec 200
        #Invoke-RestMethod -Credential $Cred -Uri $RequestUrl -ContentType "application/xml" -Method Post -Body $Request -DisableKeepAlive -TimeoutSec 200
        return $true
    }
    catch {
        Write-Host "ERROR: $($_.Exception.Message)"
        return $false
    }
}


##################################################
##                     MAIN                     ##
##################################################

$hostname = $env:COMPUTERNAME
$sDistributionServer = $($tsenv:DeployRoot).Split("\")[2]
$sRemoteLogPath = "\\$sDistributionServer\MasterLogs$"
$strLogPath = "$tsenv:LogPath\BDD.log"

# Get VM OVF data
$oVMProperties = Get-VMProperties
$vcoUrl = ($oVMProperties | ? {$_.key -eq "VCOWFURL"}).value
$vcoWfId = ($oVMProperties | ? {$_.key -eq "VCOWFID"}).value
$VmId = ($oVMProperties | ? {$_.key -eq "VCOVMID"}).value
$vcoUser = ($oVMProperties | ? {$_.key -eq "VCOUSER"}).value
$vcoPassword = ($oVMProperties | ? {$_.key -eq "VCOPASSWORD"}).value
$adminGroup = ($oVMProperties | ? {$_.key -eq "ADMINGROUP"}).value
$userGroup = ($oVMProperties | ? {$_.key -eq "USERGROUP"}).value
$environment = ($oVMProperties | ? {$_.key -eq "ENVIRONMENT"}).value
$requestor = ($oVMProperties | ? {$_.key -eq "REQUESTOR"}).value


If (Test-Path $strLogPath) {
    # Parse the log to get number of Errors and Warnings
    $result = Parse-BDDLog -Path $strLogPath
	
    # Build the vCac Message
    $sMsg = "[$($hostname)] {0} - $($Global:intError) errors, $($Global:intWarning) warnings"

    Switch ($result) {
        0 { 
			$vcacStatus = "SUCCESS"; $vcacMessage = ($sMsg -f "GOOD")
		}
        1 {
			$vcacStatus = "FAIL"; $vcacMessage = ($sMsg -f "FAIL")
		}
        2 {
			$vcacStatus = "SUCCESS"; $vcacMessage = ($sMsg -f "WARN")
		}
    }

    try {
        # Try to send feedback 3 times in case of fail
        For ($i=1; $i -le 3; $i++) {
            $Result = Send-VCACFeedback -Url $vcoUrl -WFId $vcoWfId -VMId $VmId -Status $vcacStatus -Message $vcacMessage -User $vcoUser -Password $vcoPassword
            If ($Result) {
                Break
            }
            Start-Sleep 5
        }
        If ($Result -eq $false) {
            Write-Error "Cannot send the Feedback to VCAC!"
        }
        Else {
            Write-Host "FeedBack was sent successfully to VCAC"
        }
    }
    catch {
        Write-Host "ERROR: $($_.Exception.Message)" # Used to see what happened in the remote log in case of failure
        Write-Error $_.Exception.Message
    }
    finally {
        If (Test-Path $sRemoteLogPath) {
            # Copy log file to a remote folder to centralize logs
            try {
		        Copy-Item $strLogPath "$sRemoteLogPath\$($hostname)_BDD.log" -Force
	        }
	        catch {
		        Write-Host "Unable to copy BDD.log! $($_.Exception.Message)"
	        }
        }
        Else {
            Write-Warning "$sRemoteLogPath was not found. Check if it exists and is reachable"
        }
    }
}
Else {
    Write-Error "$strLogPath not found! Cannot send VCAC Status"
}