<#
.SYNOPSIS
	Script used to refresh values of SGBUILD registry key
	depending on VMware guest info

.DESCRIPTION
	

.LINK
	

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Florian VALENTE
	Version: 1.0 (20/12/2016)
    ChangeLog: Initial version (20/12/2016)
	
.EXAMPLE
	./tagMachine.ps1

#>

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################
# Default available variables:
# - $PSScriptRoot: Script path
# - $PSScriptName: Script name without extension
# - $tsenv:SGDept: Department
# Get Conf folder
$PSConfPath = "$PSScriptRoot\conf"


##################################################
##               GLOBAL VARIABLES               ##
##################################################
# Set the path of VMware VM configuration file
$Script:CloudFilePath = "${Env:SystemRoot}\Cloud.env"


##################################################
##               Functions and Subs             ##
##################################################
# Get the VM properties object
Function Get-VMProperties {
    $Args = @{
        FilePath = "${Env:ProgramFiles}\VMware\VMware Tools\vmtoolsd.exe"
        ArgumentList = "--cmd ""info-get guestinfo.ovfenv"""
        RedirectStandardOutput = $CloudFilePath
    }
    Start-Process @Args -PassThru -Wait
    
    $xml = [xml](Get-Content $CloudFilePath)

    Remove-Item $CloudFilePath -Force | Out-Null

    return $xml.Environment.PropertySection.Property
}

##################################################
##                     MAIN                     ##
##################################################

# Registry key master signature path
$registry_path = "$tsenv:SGRegTagPath\parameters"
Write-Host "Registry path: $registry_path"

# Modify basis SG registry key
Set-ItemProperty -Path $registry_path -Name BARCODE -Value "VM_$($env:COMPUTERNAME)"
Set-ItemProperty -Path $registry_path -Name COMPUTERNAME -Value "$($env:COMPUTERNAME)"
Set-ItemProperty -Path $registry_path -Name COMMENT -Value "Cloud Server"
#$IPAddress = (Get-NetIPAddress | where-object { $_.InterfaceAlias -match "Ethernet" -and $_.AddressFamily -eq "IPv4" }).IPAddress | select -First 1
$IPAddress = (Test-Connection "$env:COMPUTERNAME" -count 1).IPV4Address.IPAddressToString
Set-ItemProperty -Path $registry_path -Name IP -Value $IPAddress

# Get VM properties
$oVMProperties = Get-VMProperties

# Get the department
$department = ($oVMProperties | ? {$_.key -eq "DEPARTMENT"}).value
# Get the VM environment
$environment = ($oVMProperties | ? {$_.key -eq "ENVIRONMENT"}).value
# Get the requestor without @ address
$requestor = ($oVMProperties | ? {$_.key -eq "REQUESTOR"}).value
# Get the customer
$customer = ($oVMProperties | ? {$_.key -eq "CUSTOMER"}).value
# Get the server type
$serverType = ($oVMProperties | ? {$_.key -eq "SERVERTYPE"}).value
# Get the trigram
$trigram = ($oVMProperties | ? {$_.key -eq "TRIGRAM"}).value


# Modify SG registry key according to VMware guest info
# Set the department (6 chars max according to GWiM constraint)
Set-ItemProperty -Path $registry_path -Name "DEPARTMENT" -Value $department.Substring(0,6).ToUpper()

# Set the country from the VM trigram
Set-ItemProperty -Path $registry_path -Name "COUNTRY" -Value $trigram.ToUpper()

# Set the environment
switch ($environment) {
    'DEV' { $environment = "DEVELOPMENT" }
    'INT' { $environment = "INTEGRATION" }
    'TST' { $environment = "TEST" }
    'UAT' { $environment = "HOMOLOGATION" }
    'PRD' { $environment = "PRODUCTION" }
    Default { $environment = "UNKNOWN ENV"; Write-Warning "ENVIRONMENT value not found!" }
}
Set-ItemProperty -Path $registry_path -Name "ENVIRONMENT" -Value $environment

# Set the requestor
Set-ItemProperty -Path $registry_path -Name "USERNAME" -Value ($requestor -split "@" | select -First 1)

# Set the server role
switch ($serverType) {
    'AP' { $serverType = "Default" }
    'DB' {
        switch (($oVMProperties | ? {$_.key -eq "DBTYPE"}).value) {
            'mssql' { $serverType = "MSSQL" }
            'oracle' { $serverType = "ORACLE" }
            'sybase' { $serverType = "SYBASE" }
            Default { $serverType = "Default"; Write-Warning "DBTYPE value not found! Using Default" }
        }
    }
    'WEB' { $serverType = "IIS" }
    'BI' { $serverType = "SSIS" }
    Default { $serverType = "Default"; Write-Warning "SERVERTYPE value not found! Using Default" }
}
Set-ItemProperty -Path $registry_path -Name "ROLE" -Value $serverType
