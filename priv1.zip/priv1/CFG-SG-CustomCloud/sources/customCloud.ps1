<#
.SYNOPSIS
	Script for customization in Cloud environment

.DESCRIPTION
	

.LINK
	

.NOTES
    Copyright: Soci�t� G�n�rale.  All rights reserved.
    Author: Baptiste HEBERT / Florian VALENTE
	Version: 1.0 (19/12/2014)
    ChangeLog: Initial version (19/12/2014)
	
.EXAMPLE
	./customCloud.ps1

#>

# Stop the script if an error occurs (try/catch, Write-Error, ...)
$ErrorActionPreference = 'Stop'


##################################################
##            ENVIRONMENT VARIABLES             ##
##################################################


##################################################
##               GLOBAL VARIABLES               ##
##################################################
$Global:CloudFilePath = "${Env:SystemRoot}\Cloud.env"
$Global:intError = 0
$Global:intWarning = 0

##################################################
##               Functions and Subs             ##
##################################################
Function Get-VMProperties {
    $Args = @{
        FilePath = "${Env:ProgramFiles}\VMware\VMware Tools\vmtoolsd.exe"
        ArgumentList = "--cmd ""info-get guestinfo.ovfenv"""
        RedirectStandardOutput = $CloudFilePath
    }
    Start-Process @Args -PassThru -Wait
    
    $xml = [xml](Get-Content $CloudFilePath)

    Remove-Item $CloudFilePath -Force | Out-Null

    return $xml.Environment.PropertySection.Property
}

Function Add-Rights {
    Param(
		[String]$AdGroup,
        [String]$LocalGroup
    )
	
	If (!([System.String]::IsNullOrEmpty($AdGroup)) -and ($AdGroup -ne "Domain Users")) {
		$Args = @{
			FilePath = "net"
			ArgumentList = "localgroup ""$($LocalGroup)"" $($AdGroup) /add"
		}
		$result = Start-Process @Args -PassThru -Wait
		Switch ($result.ExitCode) {
			0 { Write-Host "AD group $AdGroup has been add as member of $LocalGroup group" }
			1 { Write-Warning "AD group $AdGroup does not exist" }
			2 { Write-Warning "AD group $AdGroup is already member of $LocalGroup group or $LocalGroup group not found" }
			default { Write-Warning "Unknown error while adding $AdGroup in $LocalGroup group" }
		}
	}
    Else {
		Write-Host "No AD Group to add to $LocalGroup Local Group"
	}
}


##################################################
##                     MAIN                     ##
##################################################
# Get values from VM properties
$oVMProperties = Get-VMProperties

$vcoUrl = ($oVMProperties | ? {$_.key -eq "VCOWFURL"}).value
$vcoWfId = ($oVMProperties | ? {$_.key -eq "VCOWFID"}).value
$VmId = ($oVMProperties | ? {$_.key -eq "VCOVMID"}).value
$vcoUser = ($oVMProperties | ? {$_.key -eq "VCOUSER"}).value
$vcoPassword = ($oVMProperties | ? {$_.key -eq "VCOPASSWORD"}).value
$adminGroup = ($oVMProperties | ? {$_.key -eq "ADMINGROUP"}).value
$userGroup = ($oVMProperties | ? {$_.key -eq "USERGROUP"}).value
$environment = ($oVMProperties | ? {$_.key -eq "ENVIRONMENT"}).value
$requestor = ($oVMProperties | ? {$_.key -eq "REQUESTOR"}).value
$customer = ($oVMProperties | ? {$_.key -eq "CUSTOMER"}).value
$serverType = ($oVMProperties | ? {$_.key -eq "SERVERTYPE"}).value


# Modify rights according to VCAC declaration
#Add-Rights -AdGroup $userGroup -LocalGroup "Remote Desktop Users"
#Add-Rights -AdGroup $adminGroup -LocalGroup "Administrators"

Write-Host "Adding userGroup as remote desktop user if needed"
if($userGroup) {
	# check if there is domain inside the userGroup (ie. eur\userGroup) and removing it
	if($userGroup -Match "^(.*)\\([\w\-\s]+)$") {
		$userGroup = $Matches[2]
		Write-Host "Leading '$($Matches[1])' removed from userGroup"
	}
	
	try {
		([ADSI]"WinNT://./Remote Desktop Users,group").Add("WinNT://$userGroup,group")
		Write-Host "AD group $userGroup added to Remote Desktop Users local group"
	}
	catch {
		Write-Warning "AD group $userGroup couldn't be added to Remote Desktop Users local group"
	}
}

Write-Host "Adding adminGroup as administrator if needed"
if($adminGroup) {
	# check if there is domain inside the adminGroup (ie. eur\adminGroup) and removing it
	if($adminGroup -Match "^(.*)\\([\w\-\s]+)$") {
		$adminGroup = $Matches[2]
		Write-Host "Leading '$($Matches[1])' removed from adminGroup"
	}

	try {
		([ADSI]"WinNT://./Administrators,group").Add("WinNT://$adminGroup,group")
		Write-Host "AD group $adminGroup added to Administrators local group"
	}
	catch {
		Write-Warning "AD group $adminGroup couldn't be added to Administrators local group"
	}
}


# TODO WITH GWIM PACKAGE MANAGELOCALUSER AND CONFIG.XML DEPT/ROLE
<#
Write-Host "Checking server type (APP, WEB, DB, etc.)"
Write-Host "Value is: $($serverType)"
switch($serverType) {
	"WEB" {
		try {
			([ADSI]"WinNT://./Administrators,group").Add("WinNT://EUR/fr_srvweb_adm,group")
			Write-Host "AD group fr_srvweb_adm added to Administrators local group"
		}
		catch {
			Write-Warning "AD group fr_srvweb_adm couldn't be added to Administrators local group"
		}
		try {
			([ADSI]"WinNT://./Administrators,group").Add("WinNT://EUR/srv_mea_support,group")
			Write-Host "AD group srv_mea_support added to Administrators local group"
		}
		catch {
			Write-Warning "AD group srv_mea_support couldn't be added to Administrators local group"
		}
	}
	default {
		Write-Host "Nothing to do for this kind of server!"
	}
}
#>