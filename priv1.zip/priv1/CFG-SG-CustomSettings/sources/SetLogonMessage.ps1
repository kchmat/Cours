# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   2.0 (14/08/06)
# // Developer: Florian Valente
# // 
# // Purpose:   Set the Logon Message
# // Usage:     SetLogonMessage.ps1 -ConfFile <xmlFile>
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


########
# MAIN #
########
# Set path of the XML file
$xmlFile = "$PSScriptRoot\$ConfFile" -replace "#COUNTRY#", $tsenv:SGCountry

If (!(Test-Path $xmlFile)) {
    Write-Error "$ConfFile not found! Exit"
}

$xml = [xml](Get-Content $xmlFile)

$strTitle = $xml.configuration.title
$strMsg = $xml.configuration.message

# Set the Logon Title
$strRegName = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
Set-ItemProperty -Path $strRegName -Name "LegalNoticeCaption" -Value $strTitle -Force

#Set the Logon Message
Set-ItemProperty -Path $strRegName -Name "LegalNoticeText" -Value $strMsg -Force
If (!$?) {
    Write-Error "Logon Message cannot be set!"
}
Else {
    Write-Host "Logon Message setted successfully"
}
