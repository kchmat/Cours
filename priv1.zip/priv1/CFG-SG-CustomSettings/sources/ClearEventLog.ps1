# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (14/07/18)
# // Developer: Florian Valente
# // 
# // Purpose:   Clear Event Log
# // Usage:     ClearEventLog.ps1
# // ***********************************************************************************************************

$ErrorActionPreference = 'Stop'

########
# MAIN #
########
Write-Host "Clearing Event Log..."
try {
    Get-EventLog -List | % {$_.Log} | % {Clear-EventLog -LogName $_}
    Write-Host "Event Log cleared successfully"
}
catch {
    Write-Warning "Event Log not cleared ($($_.Exception.Message))"
}
