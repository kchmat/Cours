# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   2.0 (16/09/30)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Windows Start Screen
# // Usage:     SetStartScreen.ps1 -<args>
# //            Args:
# //            -OS: Filter by OS
# //            -ConfFile: Used Configuration file (must be a bin for 2012R2 and xml for 2016)
# // ***********************************************************************************************************

[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$false,ValueFromPipeline=$true)][String] $OS,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


Function Set-StartScreenWin8 {
    PARAM (
        [String] $Path
    )

    $extFile = (Get-ItemProperty $Path).Extension
    If ($extFile -eq ".bin") {
        Write-Host "Configuring Windows Start Screen for Windows 2012 R2..."
        try {
            # Import-StartLayout cmdlet creates a file in the following path
            $strLocalBinPath = "$env:SystemDrive\Users\Default\AppData\Local\Microsoft\Windows\appsFolderLayout.bin"
            # Remove it to avoid access denied issue
            If (Test-Path $strLocalBinPath) {
                Remove-Item $strLocalBinPath -Force | Out-Null
            }

            $strLayoutPath = "$env:APPDATA\layout.bin"
            Copy-Item "$Path" -Destination "$strLayoutPath" -Force | Out-Null
            # Reset Read Only attribute to avoid access denied issue when using a Standalone Media
            (Get-Item $strLayoutPath).IsReadOnly = $false

            Import-StartLayout $strLayoutPath -MountPath "$env:SystemDrive\" #Do not forget \ at the end of the MountPath otherwise it not works...

            # Remove file
            Start-Sleep 1
            Remove-Item $strLayoutPath -Force | Out-Null
            Write-Host "Start Screen configured successfully"
        }
        catch {
            Write-Warning "Cannot configure the Start Screen with $Path! $($_.Exception.Message)"
        }
    }
    Else {
        Write-Error "$Path is not a BIN file! Exit"
    }
}


Function Set-StartScreenWin10 {
    PARAM (
        [String] $Path
    )

    $extFile = (Get-ItemProperty $Path).Extension
    If ($extFile -eq ".xml") {
        Write-Host "Configuring Windows Start Screen for Windows 2016..."
        try {
            $strLayoutPath = "$env:APPDATA\layout.xml"
            Copy-Item "$Path" -Destination "$strLayoutPath" -Force | Out-Null
            # Reset Read Only attribute to avoid access denied issue when using a Standalone Media
            (Get-Item $strLayoutPath).IsReadOnly = $false

            Import-StartLayout $strLayoutPath -MountPath "$env:SystemDrive\" #Do not forget \ at the end of the MountPath otherwise it not works...

            Write-Host "Start Screen configured successfully"
        }
        catch {
            Write-Warning "Cannot configure the Start Screen with $Path! $($_.Exception.Message)"
        }
    }
    Else {
        Write-Error "$Path is not a XML file! Exit"
    }
}

########
# MAIN #
########
$strOSVersion = Get-OSVersion
If ($OS -ne $strOSVersion) {
    Write-Host "OS not match. Skip Set Start Screen"
    Exit
}

$strFilePath = "$PSScriptRoot\$ConfFile"
If (!(Test-Path $strFilePath)) {
    Write-Error "Cannot find $strFilePath! Exit"
}

Switch ($strOSVersion) {
    "6.3" {
        Set-StartScreenWin8 -Path $strFilePath
    }
    "10" {
        Set-StartScreenWin10 -Path $strFilePath
    }
    Default {
        Write-Host "The OS deployed is less than 6.3. Windows Start Screen doesn't exist. Exit"
        Exit
    }
}