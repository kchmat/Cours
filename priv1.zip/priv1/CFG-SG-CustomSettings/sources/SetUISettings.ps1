# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (14/03/03)
# // Developer: Florian Valente
# // 
# // Purpose:   Set UI Settings
# // Usage:     SetUISettings.ps1 -<args>
# //            Args:
# //            -ConfFile: Used Configuration file (must be a reg file)
# // ***********************************************************************************************************

[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


########
# MAIN #
########
$strLoadHive = "HKU\CUSTOM" #Be sure the reg file contains HKU\CUSTOM path for each reg modifications

$regFile = "$PSScriptRoot\$ConfFile"
If (!(Test-Path $regFile)) {
    Write-Error "$ConfFile was not found! UI Settings were not configured"
}
Else {
    $extFile = (Get-ItemProperty $regFile | Select-Object Extension).Extension
    If ($extFile -eq ".reg") {
        Write-Host "Loading Default NTUSER.DAT..."
        try {
            $strDefaultHive = "$($env:SystemDrive)\Users\Default\NTUSER.DAT"
            If (Test-Path $strDefaultHive) {
                REG LOAD "$strLoadHive" "$($env:SystemDrive)\Users\Default\NTUSER.DAT"
                Start-Sleep 2

                Write-Host "Importing registry file..."
                Invoke-Expression -Command "regedit.exe /s '$regFile'"
                If (!$?) {
                    Write-Error "$ConfFile not imported successfully!"
                }
                Else {
                    Write-Host "$ConfFile imported successfully!"
                }
                Start-Sleep 2

                Write-Host "Unloading Default NTUSER.DAT..."
                REG UNLOAD "$strLoadHive"
                Write-Host "Hive unloaded successfully"
            }
            Else {
                Write-Warning "$strDefaultHive was not found! UI Settings were not configured"
            }
        }
        catch {
            Write-Warning "Cannot apply $ConfFile to the Default User! $($_.Exception.Message)"
        }
    }
    Else {
        Write-Error "$ConfFile is not a REG file! Exit"
    }
}