# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.2 (10/07/2017)
# // Developer: Pierre BOUSSINGAULT
# // 
# // Purpose:   Set Windows Services
# // Usage:     SetServices.ps1
# // Arguments: -OS : Specify an operating system ('6.1','6.3' or '10')
# // 			-RegFile : Specify the registry file
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $OS,
	[Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $RegFile
)
$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


########
# MAIN #
########
If ((Get-OSVersion) -eq $OS) {
	$regFile = "$PSScriptRoot\$RegFile"
	If (!(Test-Path $regFile)) {
		Write-Error "$regFile was not found! UI Settings were not configured"
	}
	Else {
		$extFile = (Get-ItemProperty $regFile | Select-Object Extension).Extension
		If ($extFile -eq ".reg") {
			Write-Host "Importing registry file..."
			Invoke-Expression -Command "regedit.exe /s '$regFile'"
		}
		Else {
			Write-Error "$RegFile is not a REG file! Exit"
		}
	}
}
Else {
    Write-Host "$RegFile - Not a Windows Server $OS - Nothing to do"
}