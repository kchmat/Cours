# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   2.0 (14/10/21)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Acceleration Level to Full for VM
# //            Cannot be setted after VM Drivers installation because the registry key video is setted after the reboot
# // Usage:     SetVMAccelerationLevel.ps1
# // ***********************************************************************************************************

$ErrorActionPreference = 'Stop'

########
# MAIN #
########
# Set Acceleration Level to full only if it's a VM
If ($tsenv:IsVM -eq "True") {
	try {
        Write-Host "Setting Acceleration Level to Full..."
		# Get Path to Acceleration.Level
        If ((Get-OSVersion) -lt 6.3) {
            # If OS less than Windows 2012 R2, get the last video device ID
            $nbDisplay = (Get-ItemProperty "HKLM:\HARDWARE\DEVICEMAP\VIDEO").'MaxObjectNumber'
        }
        Else {
            $nbDisplay = 0
        }
		$RegValue = (Get-ItemProperty "HKLM:\HARDWARE\DEVICEMAP\VIDEO")."\Device\Video$nbDisplay"
        If (!([System.String]::IsNullOrEmpty($RegValue))) {
            $DeviceID = "$(($RegValue -split "\\")[7])"
            If (!([System.String]::IsNullOrEmpty($DeviceID))) {
                Write-Host "Video Device ID found: $DeviceID"
                # Set the full Registry Path of the Video Device
		        $RegPath = "HKLM:\$($RegValue.SubString(18))"
                If (Test-Path $RegPath) {
		            New-ItemProperty -Path "$RegPath" -Name "Acceleration.Level" -Value 0 -Force | Out-Null
		            Write-Host "Acceleration Level setted"
                }
                Else {
                    Write-Warning "Cannot found registry key $RegPath. Set Acceleration Level manually"
                }
            }
            Else {
                Write-Warning "Device ID not found. Set Acceleration Level manually"
            }
        }
        Else {
            Write-Warning "Registry key defining the Graphic Card was not found. Set Acceleration Level manually"
        }
	}
	catch {
		Write-Warning "Cannot set Acceleration Level! $($_.Exception.Message)"
	}
}
Else {
    Write-Host "Not a VM. Nothing to do."
}