# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (13/08/07)
# // Developer: Florian Valente
# // 
# // Purpose:   Set Log Off icon on All Users Desktop
# // Usage:     SetLogOffIconOnStartScreen.ps1
# // ***********************************************************************************************************

$ErrorActionPreference = 'Stop'

########
# MAIN #
########
$WshShell = New-Object -ComObject WScript.Shell

#$scPath = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Log Off.lnk" #On Start Screen is a good idea, but it's not pinned for all users...
$scPath = "$env:PUBLIC\Desktop\Log Off.lnk"
$sc = $WshShell.CreateShortcut($scPath)
$sc.TargetPath = "$env:SystemRoot\System32\shutdown.exe"
$sc.Arguments = "-l"
$sc.IconLocation = "SHELL32.dll,44"
$sc.Description = "Log off the current user"
$sc.WorkingDirectory = "$env:SystemRoot\System32"
$sc.Save()
