# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (14/01/13)
# // Developer: Florian Valente
# // 
# // Purpose:   Set File Associations
# // Usage:     SetFileAssociations.ps1 -<args>
# //            Args:
# //            -ConfFile: Used Configuration file
# // ***********************************************************************************************************

[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $ConfFile
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path


########
# MAIN #
########
# Use DISM to import file associations
# Type dism /online /export-defaultappassociations:$xmlFile to export file associations in an xml file
$xmlFile = "$PSScriptRoot\$ConfFile"
If (!(Test-Path $xmlFile)) {
    Write-Error "$ConfFile was not found! File associations were not configured"
}
Else {
    $objStatus = Start-Process -FilePath "dism.exe" -ArgumentList "/online /import-defaultappassociations:$xmlFile" -PassThru -Wait
    If ($objStatus.ExitCode -ne 0) {
        Write-Warning "Failed to configure file associations!"
    }
    Else {
        Write-Host "File associations configured successfully"
    }
}