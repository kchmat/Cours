# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (17/08/2017)
# // Developer: Pierre BOUSSINGAULT
# // 
# // Purpose:   Set Custom Backgrounds ONLY on Windows Server 2016
# // Usage:     SetCustomBackgrounds.ps1 -State Disable/enable -LockBackground "conf\$tsenv:SGDept\blue.jpg"
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $State,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $LockBackground
)

$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path

########
# MAIN #
########
$LockBackgroundDest = "C:\Windows\System32\oobe"
# Set Logon Background
Switch (Get-OSVersion) {
    "10" {
		$strLockBackgroundPath = "$PSScriptRoot\$LockBackground"
		If($State -eq "Disable")
		{
			$strLockBackgroundName = $(get-childitem "$PSScriptRoot\$LockBackground").name
			$strRegName = "HKLM:\Software\Policies\Microsoft\Windows\System"
			New-ItemProperty -Path $strRegName -PropertyType 'DWord' -Name "DisableLogonBackgroundImage" -Value "0000001" -Force
			Copy-Item $strLockBackgroundPath -Destination "$LockBackgroundDest" -Force | Out-Null
			$strRegName = "HKLM:\Software\Policies\Microsoft\Windows"
			New-Item -Path "$strRegName" -Name "Personalization" -Force
			New-ItemProperty -Path "$strRegName\Personalization" -PropertyType 'String' -Name "LockScreenImage" -Value "$LockBackgroundDest\$strLockBackgroundName" -Force
		}
		Else
		{
			Write-Host "Default Backgrounds will be used"	
		}
		
		If (!$?) {
			Write-Error "Backgrounds cannot be set!"
		}
		Else {
			Write-Host "Backgrounds set successfully"
		}
	}
	default {
		Write-Host "Not a Windows Server 2016 version : Nothing to do"
	}
}