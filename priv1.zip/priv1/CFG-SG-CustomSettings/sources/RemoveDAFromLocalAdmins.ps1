# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.1 (15/03/18)
# // Developer: Florian Valente
# // 
# // Purpose:   Remove Domain Admins group from Local Admins group
# // Usage:     RemoveDAFromLocalAdmins.ps1
# // ***********************************************************************************************************

$ErrorActionPreference = 'Stop'

Function Test-DCRole {
    $intRole = (Get-WmiObject -Class Win32_ComputerSystem).DomainRole

    If (($intRole -eq 4) -or ($intRole -eq 5)) {
        Write-Host "The server is a Domain Controller! Exit"
        return $true
    }
    return $false
}


Function Remove-DAFromLA {
    $strDomainName = Get-DomainName -Short
    $strLocalGroup = "Administrators"
    $strDomainGroup = "Domain Admins"

    Write-Host "Finding $strDomainName\$strDomainGroup in $strLocalGroup group..."
    $bFound = $false
    try {
        ([ADSI]"WinNT://./$strLocalGroup").Invoke("Members") | % {
            $strMember = $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)
            If ($strMember -match $strDomainGroup) {
                Write-Host "Group found! Removing..."
                ([ADSI]"WinNT://./$strLocalGroup").Remove("WinNT://$strDomainName/$strDomainGroup")
                Write-Host "$strDomainName\$strDomainGroup removed successfully"
                $bFound = $true
            }
        }
        If ($bFound -eq $false) {
            Write-Host "$strDomainName\$strDomainGroup not exists in $strLocalGroup group"
        }
    }
    catch {
        Write-Error "Cannot remove $strDomainName\$strDomainGroup from Local $strLocalGroup group! $($_.Exception.Message)"
    }
}



########
# MAIN #
########
# Check if the server is a DC
If (Test-DCRole) {
    Exit
}

If (Test-JoinDomain) {
    Write-Host "The server is in the domain $(Get-DomainName)"

    Remove-DAFromLA
}
Else {
    Write-Host "The server is not in a domain. Nothing to do."
}
