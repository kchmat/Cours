# // ***********************************************************************************************************
# // Copyright (c) Soci�t� G�n�rale.  All rights reserved.
# // Microsoft Deployment Toolkit Solution Accelerator
# //
# // Version:   1.0 (10/07/2017)
# // Developer: Pierre BOUSSINGAULT
# // 
# // Purpose:   Set scheduled tasks
# // Usage:     SetScheduledTasks.ps1
# // Arguments: -OS : Specify an operating system ('6.1','6.3' or '10')
# // 			-CSVFile : Specify a CSV file containing all instructions
# // ***********************************************************************************************************
[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $OS,
	[Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $CSVFile
)
$ErrorActionPreference = 'Stop'

# Get Script root
$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path

Function Delete-ScheduledTask{
    PARAM(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Task
    )
    If(Get-ScheduledTask | Where-Object {$_.TaskName -like $Task }){
	    Try{
		    Unregister-ScheduledTask -TaskName $Task -confirm:$false
		    Write-host "$Task has been deleted successfully"
        }
	    Catch{
		    Write-Warning "Cannot delete task $Task $($_.Exception.Message)"
	    }
    }
    Else{
        Write-Host "$Task does not exit. No need to delete it"
        }
}

Function Create-ScheduledTask{
#TO define
}

Function Delete-ScheduledTaskFolder{
    PARAM(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Folder
    )
	Try{
		Write-Host "Scheduled Task folder deletion ..."
        
		$ScheduleObject = New-Object -ComObject 'Schedule.Service'
		$ScheduleObject.Connect()
		$ScheduleFolder = $ScheduleObject.GetFolder((split-path $Folder))
        If(Test-Path $ScheduleFolder)
        {
		    $ScheduleFolder.DeleteFolder((split-path $Folder -leaf),$null)
		    Write-host "$Folder has been deleted successfully"
        }
        Else{
        Write-Host "$Folder does not exit. No need to delete it"
        }
	}
	Catch{
		Write-Warning "Cannot delete folder $Folder $($_.Exception.Message)"
	}
}

Function Create-ScheduledTaskFolder{
    PARAM(
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][String] $Folder
    )
	Try{
		Write-Host "Scheduled Task folder creation ..."
		$ScheduleObject = New-Object -ComObject 'Schedule.Service'
		$ScheduleObject.Connect()
		$ScheduleFolder = $ScheduleObject.GetFolder((split-path $Folder))
		$ScheduleFolder.CreateFolder((split-path $Folder -leaf))
		Write-host "$Folder has been created successfully"
	}
	Catch{
		Write-Warning "Cannot create folder $Folder $($_.Exception.Message)"
	}
}

########
# MAIN #
########
If ((Get-OSVersion) -eq $OS) {
	$CSVFile = "$PSScriptRoot\$CSVFile"
	If (!(Test-Path $CSVFile)) {
		Write-Error "$CSVFile not found! Task Scheduler has not been configured!"
	}
	Else{
		$CSVInfo = Import-CSV $CSVFile -delimiter ';'
		ForEach($Command in $CSVInfo){
			$Exp = $Command.Function + " " + $Command.Object
			Invoke-Expression $Exp
		}
	}
}
Else {
    Write-Host "Not a Windows Server $OS - Nothing to do"
}